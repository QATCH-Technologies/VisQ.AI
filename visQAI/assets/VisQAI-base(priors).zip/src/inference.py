"""
inference.py - Unified Inference and Adaptive Learning Module for VisQAI

Combines inference, uncertainty estimation, and Gated Adapter learning
into a single ViscosityPredictor class.
"""

import glob
import os
import warnings
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim

# Import core functionality
from core import (
    BASE_CATEGORICAL,
    BASE_NUMERIC,
    TARGETS,
    DataProcessor,
    EnsembleModel,
    Model,
    PhysicsInformedLoss,
    clean,
    expand_processor_and_model,
    inverse_log_transform,
    load_model_checkpoint,
    log_transform_targets,
    save_model_checkpoint,
    to_tensors,
)

# --- 1. RESIDUAL ADAPTER MODULE ---

"""
inference.py - Unified Inference and Adaptive Learning Module for VisQAI
Updated to support Concentration Splitting dimensions.
"""

import glob
import os
import warnings
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim

# Import core functionality
from core import (
    BASE_CATEGORICAL,
    BASE_NUMERIC,
    TARGETS,
    DataProcessor,
    EnsembleModel,
    Model,
    clean,
    expand_processor_and_model,
    inverse_log_transform,
    load_model_checkpoint,
    log_transform_targets,
    save_model_checkpoint,
    to_tensors,
)

# --- 1. RESIDUAL ADAPTER MODULE ---


class ResidualAdapter(nn.Module):
    """
    A lightweight network that learns corrections to the base model's predictions.
    """

    def __init__(self, numeric_dim, cat_dims, embed_dim=16):
        super().__init__()
        self.num_proj = nn.Linear(numeric_dim, embed_dim)
        self.embeddings = nn.ModuleList([nn.Embedding(n, embed_dim) for n in cat_dims])
        self.net = nn.Sequential(
            nn.Linear(embed_dim * (len(cat_dims) + 1), 64),
            nn.ReLU(),
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Linear(32, len(TARGETS)),
        )

    def forward(self, x_num, x_cat):
        embs = [emb(x_cat[:, i]) for i, emb in enumerate(self.embeddings)]
        num_emb = self.num_proj(x_num)
        x = torch.cat(embs + [num_emb], dim=1)
        return self.net(x)


# --- 2. UNIFIED VISCOSITY PREDICTOR ---


class ViscosityPredictor:
    def __init__(
        self,
        checkpoint_path: Union[str, List[str]],
        device: str = "cpu",
        is_ensemble: bool = False,
    ):
        self.device = device
        self.is_ensemble = is_ensemble
        self.adapter = None
        self._checkpoint_path = checkpoint_path
        self._hydrated = False
        self.base_vocab_sizes: Dict[str, int] = {}

        self.model = None
        self.processor = None
        self.best_params = None
        self.n_models = None

    def hydrate(self) -> "ViscosityPredictor":
        if self._hydrated:
            return self
        if self.is_ensemble:
            self._load_ensemble(self._checkpoint_path)
        else:
            self._load_single_model(self._checkpoint_path)

        self.base_vocab_sizes = {k: len(v) for k, v in self.processor.cat_maps.items()}
        self.model.eval()
        self._hydrated = True
        return self

    def _ensure_hydrated(self):
        if not self._hydrated:
            self.hydrate()

    def _load_single_model(self, checkpoint_path: str):
        self.checkpoint_path = checkpoint_path
        self.model, self.processor, self.best_params = load_model_checkpoint(
            checkpoint_path, device=self.device
        )
        self.n_models = 1

        # --- START FIX: Refresh Static Priors ---
        # The checkpoint contains old (zero) scores. We must re-run initialization
        # to apply the new logic to the loaded model.
        print("ViscosityPredictor: Refreshing static physics priors...")
        if hasattr(self.model, "physics_layers"):
            for i, layer in enumerate(self.model.physics_layers):
                if layer is not None:
                    col_name = self.model.cat_feature_names[i]
                    # Re-run the initialization method from core.py
                    self.model._init_static_priors(layer, col_name)
        # --- END FIX ---

        print(f"ViscosityPredictor: Loaded single model from {checkpoint_path}")

    def _load_ensemble(self, checkpoint_paths: Union[str, List[str]]):
        if isinstance(checkpoint_paths, str):
            if "*" in checkpoint_paths or Path(checkpoint_paths).is_dir():
                pattern = (
                    str(Path(checkpoint_paths) / "*.pt")
                    if Path(checkpoint_paths).is_dir()
                    else checkpoint_paths
                )
                checkpoint_list = sorted(glob.glob(pattern))
            else:
                checkpoint_list = [checkpoint_paths]
        else:
            checkpoint_list = checkpoint_paths

        if not checkpoint_list:
            raise ValueError("No checkpoint files provided for ensemble")

        self.model, self.processor, self.best_params = load_model_checkpoint(
            checkpoint_list[0], device=self.device
        )
        models = [self.model]
        for ckpt in checkpoint_list[1:]:
            m, _, _ = load_model_checkpoint(ckpt, device=self.device)
            models.append(m)

        self.model = EnsembleModel(models)
        self.n_models = len(models)
        print(f"ViscosityPredictor: Loaded ensemble of {self.n_models} models")

    # --- LEARNING & ADAPTATION ---

    def learn(
        self,
        df_new: pd.DataFrame,
        y_new: np.ndarray,
        epochs: int = 500,
        lr: float = 5e-3,
        analog_protein: Optional[str] = None,
    ):
        """Adapt to new data."""
        self._ensure_hydrated()
        print(f"=== Starting Adaptation Pipeline ({len(df_new)} samples) ===")

        # 1. Expand Categories
        new_cats = self.processor.detect_new_categories(df_new)
        expanded_any = False
        for feature, categories in new_cats.items():
            for cat in categories:
                sim_cat = analog_protein if feature == "Protein_type" else None
                self._smart_expand_category(feature, cat, similar_category=sim_cat)
                expanded_any = True

        if not expanded_any:
            print("  [Info] No new categories detected.")

        # 2. Train Adapter
        self._train_gated_adapter(df_new, y_new, n_epochs=epochs, lr=lr)
        print("=== Adaptation Complete ===")

    def _smart_expand_category(
        self,
        feature_name: str,
        new_category: str,
        similar_category: Optional[str] = None,
    ):
        """Expand vocabulary and embeddings."""
        if feature_name not in self.processor.categorical_features:
            return
        if new_category in self.processor.cat_maps[feature_name]:
            return

        print(f"  [Expansion] Adding '{new_category}' to {feature_name}...")
        self.processor.add_categories(feature_name, [new_category])

        idx = self.model.cat_feature_names.index(feature_name)
        old_emb = self.model.embeddings[idx]
        new_vocab_size = old_emb.num_embeddings + 1
        new_emb_layer = nn.Embedding(new_vocab_size, old_emb.embedding_dim)

        with torch.no_grad():
            new_emb_layer.weight[:-1] = old_emb.weight
            if (
                similar_category
                and similar_category in self.processor.cat_maps[feature_name]
            ):
                try:
                    sim_idx = self.processor.cat_maps[feature_name].index(
                        similar_category
                    )
                    noise = torch.randn(old_emb.embedding_dim) * 0.01
                    new_emb_layer.weight[-1] = (old_emb.weight[sim_idx] * 1.5) + noise
                except ValueError:
                    new_emb_layer.weight[-1] = old_emb.weight.mean(dim=0)
            else:
                new_emb_layer.weight[-1] = old_emb.weight.mean(dim=0)

        self.model.embeddings[idx] = new_emb_layer.to(self.device)
        self.model.cat_maps[feature_name].append(new_category)

    def _train_gated_adapter(
        self, df_new: pd.DataFrame, y_new: np.ndarray, n_epochs: int, lr: float
    ):
        """
        Train the Gated Residual Adapter.
        [FIXED]: Calculates num_dim from transformed data to handle split columns.
        """
        print("  [Adapter] Initializing Residual Adapter...")

        # 1. Transform FIRST to get correct shapes (Low/High splits)
        X_num, X_cat = self.processor.transform(df_new)

        # 2. Determine Correct Dimensions
        cat_dims = [len(m) for m in self.processor.cat_maps.values()]
        num_dim = X_num.shape[
            1
        ]  # <--- FIXED: Uses actual numeric width (e.g., 50 instead of 46)

        self.adapter = ResidualAdapter(num_dim, cat_dims, embed_dim=16).to(self.device)
        optimizer = optim.Adam(self.adapter.parameters(), lr=lr)
        loss_fn = nn.MSELoss()

        y_log = log_transform_targets(y_new)
        y_log_t = torch.tensor(y_log, dtype=torch.float32).to(self.device)

        with torch.no_grad():
            X_num_t, X_cat_t = to_tensors(X_num, X_cat)
            X_num_t = X_num_t.to(self.device)
            X_cat_t = X_cat_t.to(self.device)
            # Base model prediction
            base_preds = self.model(X_num_t, X_cat_t)

        target_residuals = y_log_t - base_preds

        # 3. Train
        self.adapter.train()
        for epoch in range(n_epochs):
            optimizer.zero_grad()
            pred_residuals = self.adapter(X_num_t, X_cat_t)
            loss = loss_fn(pred_residuals, target_residuals)
            loss.backward()
            optimizer.step()

        self._attach_gated_adapter()

    def hydrate_adapter(
        self, df_support: pd.DataFrame, n_epochs: int = 500, lr: float = 5e-3
    ):
        """Restore adapter state from support set."""
        self._ensure_hydrated()
        print("  [Adapter] Hydrating Adapter State...")

        # 1. Transform Data
        X_num, X_cat = self.processor.transform(df_support)
        y_true = df_support[TARGETS].values
        y_log = log_transform_targets(y_true)

        # 2. Setup Architecture (FIXED DIMENSIONS)
        cat_dims = [len(m) for m in self.processor.cat_maps.values()]
        num_dim = X_num.shape[1]  # <--- FIXED

        self.adapter = ResidualAdapter(num_dim, cat_dims, embed_dim=16).to(self.device)

        with torch.no_grad():
            X_num_t, X_cat_t, y_log_t = to_tensors(X_num, X_cat, y_log)
            X_num_t = X_num_t.to(self.device)
            X_cat_t = X_cat_t.to(self.device)
            y_log_t = y_log_t.to(self.device)
            base_preds = self.model(X_num_t, X_cat_t)

        target_residuals = y_log_t - base_preds

        optimizer = optim.Adam(self.adapter.parameters(), lr=lr)
        loss_fn = nn.MSELoss()

        self.adapter.train()
        for i in range(n_epochs):
            optimizer.zero_grad()
            pred = self.adapter(X_num_t, X_cat_t)
            loss = loss_fn(pred, target_residuals)
            loss.backward()
            optimizer.step()

        self._attach_gated_adapter()

    def _attach_gated_adapter(self):
        """Dynamically attach adapter with gating."""
        if self.adapter is None:
            return

        self.adapter.eval()
        original_forward = self.model.forward

        gating_thresholds = []
        for feat, base_size in self.base_vocab_sizes.items():
            if feat in self.model.cat_feature_names:
                idx = self.model.cat_feature_names.index(feat)
                gating_thresholds.append((idx, base_size))

        def new_forward(x_n, x_c):
            base = original_forward(x_n, x_c)
            adapt = self.adapter(x_n, x_c)

            mask = torch.zeros(x_c.size(0), 1, dtype=torch.bool, device=x_c.device)
            for col_idx, cutoff in gating_thresholds:
                is_new = x_c[:, col_idx] >= cutoff
                mask = mask | is_new.unsqueeze(1)

            return base + (adapt * mask.float())

        self.model.forward = new_forward
        print("  [Adapter] Dynamic Multi-Feature Gating attached.")

    def predict(
        self, df: pd.DataFrame, return_log_space: bool = False, batch_size: int = 256
    ) -> np.ndarray:
        self._ensure_hydrated()
        self.model.eval()

        new_cats = self.processor.detect_new_categories(df)
        if new_cats:
            for feature, categories in new_cats.items():
                expand_processor_and_model(
                    self.processor, self.model, feature, categories
                )

        X_num, X_cat = self.processor.transform(df)
        X_num_t, X_cat_t = to_tensors(X_num, X_cat)
        X_num_t = X_num_t.to(self.device)
        X_cat_t = X_cat_t.to(self.device)

        predictions = []
        with torch.no_grad():
            for i in range(0, len(X_num_t), batch_size):
                batch_num = X_num_t[i : i + batch_size]
                batch_cat = X_cat_t[i : i + batch_size]
                pred = self.model(batch_num, batch_cat)
                predictions.append(pred.cpu().numpy())

        predictions = np.vstack(predictions)
        if not return_log_space:
            predictions = inverse_log_transform(predictions)
        return predictions

    def predict_with_uncertainty(
        self, df: pd.DataFrame, n_samples: int = 30, confidence_level: float = 0.95
    ) -> Dict[str, np.ndarray]:
        """
        Predicts with uncertainty using Monte Carlo Dropout.
        """
        self._ensure_hydrated()

        self.model.train()  # Enable Dropout

        # Ensure categories exist
        new_cats = self.processor.detect_new_categories(df)
        if new_cats:
            for feature, categories in new_cats.items():
                expand_processor_and_model(
                    self.processor, self.model, feature, categories
                )

        X_num, X_cat = self.processor.transform(df)
        X_num_t, X_cat_t = to_tensors(X_num, X_cat)
        X_num_t = X_num_t.to(self.device)
        X_cat_t = X_cat_t.to(self.device)

        mc_preds = []
        for _ in range(n_samples):
            with torch.no_grad():
                pred = self.model(X_num_t, X_cat_t)
                mc_preds.append(pred.cpu().numpy())

        mc_preds = np.array(mc_preds)
        mc_preds_linear = inverse_log_transform(mc_preds)

        mean_pred = mc_preds_linear.mean(axis=0)
        std_pred = mc_preds_linear.std(axis=0)

        alpha = 1 - confidence_level
        lower = np.percentile(mc_preds_linear, (alpha / 2) * 100, axis=0)
        upper = np.percentile(mc_preds_linear, (1 - alpha / 2) * 100, axis=0)

        self.model.eval()

        return {
            "mean": mean_pred,
            "std": std_pred,
            "lower_ci": lower,
            "upper_ci": upper,
        }

    def predict_with_physics(self, df: pd.DataFrame) -> Tuple[np.ndarray, List[Dict]]:
        """
        Returns predictions AND physics parameters.
        Iterates generically over all tracked parameters in 'details'.
        """
        self._ensure_hydrated()
        self.model.eval()

        new_cats = self.processor.detect_new_categories(df)
        if new_cats:
            for feature, categories in new_cats.items():
                expand_processor_and_model(
                    self.processor, self.model, feature, categories
                )

        # 1. Force Regime & CCI Calculation
        regime_series = self.processor._compute_regime(df)
        df["Regime"] = regime_series

        X_num, X_cat = self.processor.transform(df)
        X_num_t, X_cat_t = to_tensors(X_num, X_cat)
        X_num_t = X_num_t.to(self.device)
        X_cat_t = X_cat_t.to(self.device)

        predictions = []
        physics_records = []

        with torch.no_grad():
            batch_size = 256
            for i in range(0, len(X_num_t), batch_size):
                b_num = X_num_t[i : i + batch_size]
                b_cat = X_cat_t[i : i + batch_size]

                # Forward pass with physics details
                pred, batch_details = self.model(
                    b_num, b_cat, return_physics_details=True
                )

                predictions.append(pred.cpu().numpy())

                curr_batch_size = b_num.shape[0]
                start_idx = i

                for j in range(curr_batch_size):
                    global_idx = start_idx + j
                    sample_record = {}

                    # --- UPDATED: Generic Loop ---
                    # Automatically saves everything packed in 'details' (e.g. base_term, conc_term)
                    for layer_name, params in batch_details.items():
                        for param_name, tensor_val in params.items():
                            # param_name is "base_term", "w_L", etc.
                            # tensor_val[j] is the value for this specific sample
                            sample_record[f"{layer_name}_{param_name}"] = tensor_val[
                                j
                            ].item()

                    # 2. Regime Tracking
                    sample_record["Calc_CCI_Score"] = df.iloc[global_idx].get(
                        "CCI_Score", np.nan
                    )
                    sample_record["Regime_Class"] = df.iloc[global_idx].get(
                        "Regime", "unknown"
                    )

                    physics_records.append(sample_record)

        predictions = np.vstack(predictions)
        predictions = inverse_log_transform(predictions)

        return predictions, physics_records

    def save_checkpoint(self, filepath: str):
        self._ensure_hydrated()
        save_model_checkpoint(self.model, self.processor, self.best_params, filepath)
        print(f"Saved checkpoint to: {filepath}")


if __name__ == "__main__":
    print("Inference Module Loaded.")
    print("ViscosityPredictor now supports .learn() for adaptation.")
    print("ViscosityPredictor supports lazy loading - model loads on first use.")
