# import json
# import pickle
# import warnings
# from datetime import datetime
# from typing import Dict, List, Optional, Tuple, Union

# import numpy as np
# import pandas as pd
# import torch
# import torch.nn as nn
# import torch.nn.functional as F
# from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
# from sklearn.preprocessing import StandardScaler

# # --- CONFIGURATION ---
# BASE_CATEGORICAL = [
#     "Protein_type",
#     "Protein_class_type",
#     "Buffer_type",
#     "Salt_type",
#     "Stabilizer_type",
#     "Surfactant_type",
#     "Excipient_type",
# ]

# BASE_NUMERIC = [
#     "MW",
#     "Protein_conc",
#     "Temperature",
#     "Buffer_pH",
#     "Buffer_conc",
#     "Salt_conc",
#     "Stabilizer_conc",
#     "Surfactant_conc",
#     "Excipient_conc",
#     "kP",
#     "C_Class",
#     "HCI",
# ]

# TARGETS = [
#     "Viscosity_100",
#     "Viscosity_1000",
#     "Viscosity_10000",
#     "Viscosity_100000",
#     "Viscosity_15000000",
# ]

# # --- CONCENTRATION THRESHOLDS (New) ---
# # Units assumed to match input data (e.g. mM for salts, M for sugars, % for surfactants)
# CONC_THRESHOLDS = {
#     # Salts / Excipients (mM)
#     "arginine": 150.0,
#     "lysine": 100.0,
#     "proline": 200.0,
#     "nacl": 150.0,
#     # Surfactants (%)
#     "tween": 0.01,
#     "polysorbate": 0.01,
#     # Stabilizers (M - assuming 0.2M inputs)
#     "sucrose": 200.0,  # Assuming inputs are mM. If M, change to 0.2
#     "trehalose": 200.0,  # Assuming inputs are mM. If M, change to 0.2
# }

# # --- PHYSICS PRIORS ---

# # 1. Corrected Dictionary (Fixed the 'noprotein' key)
# EXCIPIENT_PRIORS = {
#     # Format: (Protein_Class, Regime): {Excipient_Name: Effect_Value}
#     # --- SPECIAL REGIME: NO PROTEIN ---
#     # CHANGED: Fixed key from 3-tuple ("noprotein", "noprotein", "none") to 2-tuple to match code logic
#     ("noprotein", "noprotein"): {
#         "nacl": 0.1,
#         "arginine": 0.1,
#         "lysine": 0.1,
#         "proline": 0.1,
#         "sucrose": 1.0,
#         "trehalose": 1.0,
#         "tween": 0.1,
#         "polysorbate": 0.1,
#     },
#     # --- IgG1 ---
#     ("mab_igg1", "near"): {
#         "arginine": -2,
#         "lysine": -1,
#         "nacl": -1,
#         "proline": 0,
#         "sucrose": 1,
#         "tween": -1,
#     },
#     ("mab_igg1", "mixed"): {
#         "arginine": -1,
#         "lysine": -1,
#         "nacl": -1,
#         "proline": -1,
#         "sucrose": 1,
#         "tween": -1,
#     },
#     ("mab_igg1", "far"): {
#         "arginine": 0,
#         "lysine": -1,
#         "nacl": -1,
#         "proline": -1,
#         "sucrose": 1,
#         "tween": -1,
#     },
#     # --- IgG4 ---
#     ("mab_igg4", "near"): {
#         "arginine": -2,
#         "lysine": -1,
#         "nacl": -1,
#         "proline": 0,
#         "sucrose": 1,
#         "tween": -1,
#     },
#     ("mab_igg4", "mixed"): {
#         "arginine": -2,
#         "lysine": -1,
#         "nacl": -1,
#         "proline": -1,
#         "sucrose": 1,
#         "tween": -1,
#     },
#     ("mab_igg4", "far"): {
#         "arginine": -1,
#         "lysine": -1,
#         "nacl": -1,
#         "proline": -1,
#         "sucrose": 1,
#         "tween": -1,
#     },
#     # --- Fc-Fusion ---
#     ("fc-fusion", "near"): {
#         "arginine": -1,
#         "lysine": -1,
#         "nacl": -1,
#         "proline": -1,
#         "sucrose": 1,
#         "tween": -2,
#     },
#     ("fc-fusion", "mixed"): {
#         "arginine": -1,
#         "lysine": 0,
#         "nacl": 0,
#         "proline": -2,
#         "sucrose": 1,
#         "tween": -2,
#     },
#     ("fc-fusion", "far"): {
#         "arginine": 0,
#         "lysine": 0,
#         "nacl": 0,
#         "proline": -2,
#         "sucrose": 1,
#         "tween": -2,
#     },
#     # --- Bispecific ---
#     ("bispecific", "near"): {
#         "arginine": -2,
#         "lysine": -1,
#         "nacl": -1,
#         "proline": 0,
#         "sucrose": 1,
#         "tween": -1,
#     },
#     ("bispecific", "mixed"): {
#         "arginine": -1,
#         "lysine": 0,
#         "nacl": 0,
#         "proline": -1,
#         "sucrose": 1,
#         "tween": -2,
#     },
#     ("bispecific", "far"): {
#         "arginine": 0,
#         "lysine": 0,
#         "nacl": 0,
#         "proline": -1,
#         "sucrose": 1,
#         "tween": -2,
#     },
#     # --- Other/Fallback ---
#     ("other", "near"): {
#         "arginine": -1,
#         "lysine": -1,
#         "nacl": -1,
#         "proline": 0,
#         "sucrose": 1,
#         "tween": 0,
#     },
#     ("other", "mixed"): {
#         "arginine": 0,
#         "lysine": 0,
#         "nacl": 0,
#         "proline": -1,
#         "sucrose": 1,
#         "tween": 0,
#     },
#     ("other", "far"): {
#         "arginine": 0,
#         "lysine": 0,
#         "nacl": 0,
#         "proline": -1,
#         "sucrose": 1,
#         "tween": 0,
#     },
#     # POLYCLONAL
#     ("polyclonal", "near"): {
#         "arginine": -1,
#         "lysine": -1,
#         "nacl": -1,
#         "proline": 0,
#         "sucrose": 1,
#         "tween": 0,
#     },
#     ("polyclonal", "mixed"): {
#         "arginine": 0,
#         "lysine": 0,
#         "nacl": 0,
#         "proline": -1,
#         "sucrose": 1,
#         "tween": 0,
#     },
#     ("polyclonal", "far"): {
#         "arginine": 0,
#         "lysine": 0,
#         "nacl": 0,
#         "proline": -1,
#         "sucrose": 1,
#         "tween": 0,
#     },
# }

# # Map specific column names to the generic types in the Prior Table
# EXCIPIENT_TYPE_MAPPING = {
#     "Salt_type": ["nacl"],
#     "Excipient_type": ["arginine", "lysine", "proline"],
#     "Stabilizer_type": ["sucrose", "trehalose"],
#     "Surfactant_type": ["tween", "polysorbate"],
# }

# # Map conc columns to type columns for splitting logic
# CONC_TYPE_PAIRS = {
#     "Salt_conc": "Salt_type",
#     "Stabilizer_conc": "Stabilizer_type",
#     "Surfactant_conc": "Surfactant_type",
#     "Excipient_conc": "Excipient_type",
# }

# # --- DATA UTILITIES ---


# def clean(
#     df: pd.DataFrame,
#     numeric_cols: List[str],
#     categorical_cols: List[str],
#     target_cols: Optional[List[str]] = None,
# ) -> pd.DataFrame:
#     """Clean and preprocess dataframe."""
#     df_clean = df.copy()
#     bad_str = {"nan", "none", "null", "", "na", "n/a"}

#     for col in df_clean.columns:
#         if df_clean[col].dtype == object:
#             df_clean[col] = (
#                 df_clean[col]
#                 .astype(str)
#                 .str.strip()
#                 .str.lower()
#                 .replace(bad_str, np.nan)
#             )

#     conc_cols = [c for c in numeric_cols if "conc" in c.lower()]
#     phys_cols = [c for c in numeric_cols if c not in conc_cols]

#     for col in numeric_cols:
#         df_clean[col] = pd.to_numeric(df_clean[col], errors="coerce")

#     df_clean[conc_cols] = df_clean[conc_cols].fillna(0.0)

#     for col in phys_cols:
#         if col in df_clean.columns:
#             median_val = df_clean[col].median()
#             if pd.isna(median_val):
#                 median_val = 0
#             df_clean[col] = df_clean[col].fillna(median_val)

#     for col in categorical_cols:
#         df_clean[col] = df_clean[col].replace({np.nan: "none"})

#     if target_cols:
#         for col in target_cols:
#             df_clean[col] = pd.to_numeric(df_clean[col], errors="coerce")
#         df_clean = df_clean.dropna(subset=target_cols)
#         for col in target_cols:
#             df_clean = df_clean[df_clean[col] > 0]

#     return df_clean


# def log_transform_targets(y: np.ndarray) -> np.ndarray:
#     return np.log10(y + 1e-8)


# def inverse_log_transform(y_log: np.ndarray) -> np.ndarray:
#     return 10**y_log - 1e-8


# def to_tensors(X_num, X_cat, y=None, weights=None):
#     tensors = [
#         torch.tensor(X_num, dtype=torch.float32),
#         torch.tensor(X_cat, dtype=torch.long),
#     ]
#     if y is not None:
#         tensors.append(torch.tensor(y, dtype=torch.float32))
#     if weights is not None:
#         tensors.append(torch.tensor(weights, dtype=torch.float32))
#     return tuple(tensors)


# class LearnablePhysicsPrior(nn.Module):
#     """
#     Implements the learnable weighted physics prior logic.
#     Scores are initialized by the Model class.
#     """

#     def __init__(self, n_classes, n_regimes, n_excipients):
#         super().__init__()
#         # Buffer for static scores (initialized by Model._init_static_priors)
#         self.register_buffer(
#             "static_scores", torch.zeros(n_classes, n_regimes, n_excipients)
#         )

#         # Learnable parameters
#         self.delta = nn.Parameter(torch.zeros(n_classes, n_regimes, n_excipients))
#         self.w_L = nn.Parameter(torch.ones(n_classes, n_regimes, n_excipients) * 0.5)
#         self.w_H = nn.Parameter(torch.ones(n_classes, n_regimes, n_excipients) * 1.0)

#     def forward(self, p_idx, r_idx, e_idx, e_low_norm, e_high_norm):
#         # 1. Fetch parameters
#         score = self.static_scores[p_idx, r_idx, e_idx]
#         d = torch.clamp(self.delta[p_idx, r_idx, e_idx], min=-2.0, max=2.0)
#         wl = self.w_L[p_idx, r_idx, e_idx]
#         wh = self.w_H[p_idx, r_idx, e_idx]

#         # 2. Compute components
#         # Ensure correct squeezing for tracking
#         el = e_low_norm.squeeze()
#         eh = e_high_norm.squeeze()

#         base_term = score + d
#         conc_term = (wl * el) + (wh * eh)

#         # 3. Final calculation
#         result = base_term * conc_term

#         # 4. Pack ALL details for inspection [UPDATED]
#         details = {
#             "static_score": score,
#             "delta": d,
#             "w_L": wl,
#             "w_H": wh,
#             "e_low_norm": el,  # <--- Added
#             "e_high_norm": eh,  # <--- Added
#             "base_term": base_term,  # <--- Added
#             "conc_term": conc_term,  # <--- Added
#             "result": result,
#         }
#         return result.unsqueeze(1), details


# class EmbeddingDropout(nn.Module):
#     """Drop entire embedding vectors, not individual dimensions."""

#     def __init__(self, p: float):
#         super().__init__()
#         self.p = p

#     def forward(self, x):
#         if not self.training or self.p == 0:
#             return x
#         mask = (torch.rand(x.size(0), 1, device=x.device) > self.p).float()
#         return x * mask


# class ResidualBlock(nn.Module):
#     def __init__(self, dim, dropout):
#         super().__init__()
#         self.fc = nn.Linear(dim, dim)
#         self.norm = nn.LayerNorm(dim)
#         self.act = nn.ReLU()
#         self.drop = nn.Dropout(dropout)

#     def forward(self, x):
#         residual = x
#         x = self.fc(x)
#         x = self.norm(x)
#         x = self.act(x)
#         x = self.drop(x)
#         return x + residual


# class Model(nn.Module):
#     def __init__(
#         self,
#         cat_maps: Dict,
#         numeric_dim: int,
#         out_dim: int,
#         hidden_sizes: List[int],
#         dropout: float,
#         split_indices: Dict[str, Tuple[int, int]] = None,
#     ):
#         super().__init__()
#         self.cat_feature_names = list(cat_maps.keys())
#         self.cat_maps = {k: list(v) for k, v in cat_maps.items()}
#         self.split_indices = split_indices or {}

#         # 1. Store indices of "none" for robust masking
#         self.none_indices = {}
#         for col, categories in self.cat_maps.items():
#             # Try to find 'none', 'nan', 'null' in the map
#             none_idx = -1
#             for candidate in ["none", "nan", "null", "n/a"]:
#                 if candidate in categories:
#                     none_idx = categories.index(candidate)
#                     break
#             self.none_indices[col] = none_idx

#         # Indices
#         self.p_class_idx = (
#             self.cat_feature_names.index("Protein_class_type")
#             if "Protein_class_type" in self.cat_feature_names
#             else -1
#         )
#         self.regime_idx = (
#             self.cat_feature_names.index("Regime")
#             if "Regime" in self.cat_feature_names
#             else -1
#         )

#         self.emb_drop = EmbeddingDropout(0.05)

#         # Embeddings
#         self.embeddings = nn.ModuleList()
#         # Physics Layers
#         self.physics_layers = nn.ModuleList()
#         self.physics_col_indices = []

#         for i, col in enumerate(self.cat_feature_names):
#             vocab = len(self.cat_maps[col])
#             emb_dim = min(32, max(4, int(vocab**0.5 * 2)))
#             self.embeddings.append(nn.Embedding(vocab, emb_dim))

#             # Setup Physics Layer
#             if (
#                 self.p_class_idx != -1
#                 and col in EXCIPIENT_TYPE_MAPPING
#                 and col in CONC_TYPE_PAIRS.values()
#             ):
#                 conc_col_name = [k for k, v in CONC_TYPE_PAIRS.items() if v == col][0]

#                 if conc_col_name in self.split_indices:
#                     n_classes = len(self.cat_maps["Protein_class_type"])
#                     n_regimes = len(self.cat_maps["Regime"])
#                     n_excipients = len(self.cat_maps[col])

#                     phys_layer = LearnablePhysicsPrior(
#                         n_classes, n_regimes, n_excipients
#                     )

#                     # Initialize with robust logic
#                     self._init_static_priors(phys_layer, col)

#                     self.physics_layers.append(phys_layer)
#                     self.physics_col_indices.append(i)
#                 else:
#                     self.physics_layers.append(None)
#                     self.physics_col_indices.append(-1)
#             else:
#                 self.physics_layers.append(None)
#                 self.physics_col_indices.append(-1)

#         total_emb = sum(e.embedding_dim for e in self.embeddings)

#         self.regime_gate = None
#         if self.regime_idx != -1:
#             num_regimes = len(self.cat_maps["Regime"])
#             self.regime_gate = nn.Embedding(num_regimes, 1)
#             nn.init.constant_(self.regime_gate.weight, 1.0)

#         # Residual Blocks
#         self.residual_blocks = nn.ModuleList()
#         for h in hidden_sizes:
#             self.residual_blocks.append(ResidualBlock(h, dropout))

#         # Base Network
#         layers = []
#         prev = total_emb + numeric_dim
#         for h in hidden_sizes:
#             layers.append(nn.Linear(prev, h))
#             layers.append(nn.LayerNorm(h))
#             layers.append(nn.ReLU())
#             layers.append(nn.Dropout(dropout))
#             prev = h
#         self.base = nn.Sequential(*layers)

#         # Heads
#         self.heads = nn.ModuleList([nn.Linear(prev, 1) for _ in range(out_dim)])

#     def _init_static_priors(self, layer, col_name):
#         p_classes = self.cat_maps["Protein_class_type"]
#         regimes = self.cat_maps["Regime"]
#         excipients = self.cat_maps[col_name]

#         tensor = layer.static_scores

#         with torch.no_grad():
#             for p_i, p_val in enumerate(p_classes):
#                 for r_i, r_val in enumerate(regimes):
#                     for e_i, e_val in enumerate(excipients):

#                         # 1. Normalize Keys
#                         p_key = p_val.lower().strip()
#                         r_key = r_val.lower().strip()
#                         e_key = e_val.lower().strip()

#                         # 2. FIND PRIOR DICTIONARY (Tuple Lookup)
#                         prior_dict = None

#                         # Helper to find tuple key (class, regime) case-insensitively
#                         def find_prior_dict(pk, rk):
#                             if (pk, rk) in EXCIPIENT_PRIORS:
#                                 return EXCIPIENT_PRIORS[(pk, rk)]
#                             for (dict_p, dict_r), val in EXCIPIENT_PRIORS.items():
#                                 if (
#                                     str(dict_p).lower().strip() == pk
#                                     and str(dict_r).lower().strip() == rk
#                                 ):
#                                     return val
#                             return None

#                         # Primary Lookup
#                         prior_dict = find_prior_dict(p_key, r_key)

#                         # Fallback 1: noprotein
#                         if prior_dict is None and (
#                             p_key in ["noprotein", "none"] or r_key == "noprotein"
#                         ):
#                             prior_dict = find_prior_dict("noprotein", "noprotein")

#                         # Fallback 2: other
#                         if prior_dict is None:
#                             prior_dict = find_prior_dict("other", r_key)

#                         if prior_dict is None:
#                             continue

#                         # 3. LOOKUP EXCIPIENT VALUE
#                         effect = 0.0
#                         target_key = None
#                         if "tween" in e_key:
#                             target_key = "tween"
#                         elif "sucrose" in e_key:
#                             target_key = "sucrose"
#                         elif "nacl" in e_key:
#                             target_key = "nacl"

#                         if target_key:
#                             # Direct check
#                             if target_key in prior_dict:
#                                 effect = float(prior_dict[target_key])
#                             else:
#                                 # Case-insensitive scan
#                                 for k, v in prior_dict.items():
#                                     if str(k).lower().strip() == target_key:
#                                         effect = float(v)
#                                         break

#                         tensor[p_i, r_i, e_i] = effect

#     def forward(
#         self, x_num, x_cat, return_features=False, return_physics_details=False
#     ):
#         # 1. Embeddings & Base Network
#         embs = [emb(x_cat[:, i]) for i, emb in enumerate(self.embeddings)]
#         emb_cat = torch.cat(embs, dim=1)
#         emb_cat = self.emb_drop(emb_cat)
#         x = torch.cat([emb_cat, x_num], dim=1)
#         x = self.base(x)

#         if self.residual_blocks:
#             for block in self.residual_blocks:
#                 x = block(x)

#         if return_features:
#             features = x.clone()

#         outputs = [head(x) for head in self.heads]
#         pred = torch.cat(outputs, dim=1)

#         # 2. Learnable Physics Correction
#         physics_details = {}

#         if self.p_class_idx != -1:
#             p_idx = x_cat[:, self.p_class_idx]
#             r_idx = x_cat[:, self.regime_idx]
#             total_correction = 0.0

#             for i, phys_layer in enumerate(self.physics_layers):
#                 if phys_layer is not None:
#                     e_idx = x_cat[:, i]
#                     col_name = self.cat_feature_names[i]
#                     conc_name = [
#                         k for k, v in CONC_TYPE_PAIRS.items() if v == col_name
#                     ][0]
#                     idx_low, idx_high = self.split_indices[conc_name]

#                     val_low = x_num[:, idx_low : idx_low + 1]
#                     val_high = x_num[:, idx_high : idx_high + 1]

#                     # --- UPDATED MASK LOGIC ---
#                     # Only mask if e_idx matches the specific 'none' index for this column
#                     none_idx = self.none_indices.get(col_name, -1)

#                     if none_idx != -1:
#                         mask = (e_idx != none_idx).float().unsqueeze(1)
#                     else:
#                         # If no 'none' category exists, assume all valid
#                         mask = torch.ones_like(e_idx).float().unsqueeze(1)
#                     # --------------------------

#                     correction, layer_details = phys_layer(
#                         p_idx, r_idx, e_idx, val_low, val_high
#                     )

#                     total_correction = total_correction + (correction * mask)

#                     if return_physics_details:
#                         physics_details[col_name] = {
#                             k: v * mask.squeeze() for k, v in layer_details.items()
#                         }

#             pred = pred + total_correction

#         # 3. Regime Gate
#         if self.regime_gate is not None and self.regime_idx != -1:
#             gate = self.regime_gate(x_cat[:, self.regime_idx])
#             gate = torch.sigmoid(gate)
#             pred = pred * gate

#         ret = [pred]
#         if return_features:
#             ret.append(features)
#         if return_physics_details:
#             ret.append(physics_details)

#         if len(ret) == 1:
#             return ret[0]
#         return tuple(ret)

#     def expand_categorical_embedding(
#         self, feature_name: str, new_categories: List[str], initialization: str = "mean"
#     ) -> None:
#         """
#         Expand an embedding layer to accommodate new categories.

#         NOTE: If the expanded feature is involved in a Physics Layer (e.g. Excipient_type),
#         this method currently does NOT resize the physics tensors.
#         The model will function, but new categories will effectively have 0 physics score.
#         """
#         if feature_name not in self.cat_feature_names:
#             raise ValueError(f"Feature {feature_name} not in categorical features")

#         idx = self.cat_feature_names.index(feature_name)
#         old_emb = self.embeddings[idx]
#         old_vocab_size = len(self.cat_maps[feature_name])
#         new_vocab_size = old_vocab_size + len(new_categories)

#         # 1. Create new embedding layer
#         new_emb = nn.Embedding(new_vocab_size, old_emb.embedding_dim)

#         # 2. Copy old weights and initialize new ones
#         with torch.no_grad():
#             # Copy existing knowledge
#             new_emb.weight[:old_vocab_size] = old_emb.weight

#             # Initialize new categories
#             if initialization == "mean":
#                 # Start with the average of existing embeddings + noise
#                 mean_embedding = old_emb.weight.mean(dim=0)
#                 for i in range(len(new_categories)):
#                     noise = torch.randn_like(mean_embedding) * 0.01
#                     new_emb.weight[old_vocab_size + i] = mean_embedding + noise
#             elif initialization == "zero":
#                 new_emb.weight[old_vocab_size:] = 0.0

#         # 3. Replace the layer
#         self.embeddings[idx] = new_emb

#         # 4. Update internal map
#         self.cat_maps[feature_name].extend(new_categories)

#         # 5. Check Physics Layer Compatibility
#         if self.physics_layers[idx] is not None:
#             print(
#                 f"  [Warning] Expanded '{feature_name}' which has a Physics Prior attached."
#             )
#             print(
#                 f"            The new categories {new_categories} will have 0 physics effect"
#             )
#             print(f"            until the physics tensor is manually resized.")

#         print(
#             f"Expanded {feature_name} from {old_vocab_size} to {new_vocab_size} categories"
#         )


# class EnsembleModel(nn.Module):
#     """Ensemble wrapper for multiple models with uncertainty quantification."""

#     def __init__(self, models: List[nn.Module]):
#         super().__init__()
#         self.models = nn.ModuleList(models)

#     @property
#     def cat_maps(self) -> Dict:
#         """Proxy to first model's cat_maps for consistent interface."""
#         return self.models[0].cat_maps

#     @property
#     def cat_feature_names(self) -> List[str]:
#         """Proxy to first model's cat_feature_names for consistent interface."""
#         return self.models[0].cat_feature_names

#     @property
#     def embeddings(self) -> nn.ModuleList:
#         """Proxy to first model's embeddings for consistent interface."""
#         return self.models[0].embeddings

#     def forward(self, x_num, x_cat):
#         """Forward pass returning mean prediction."""
#         outputs = [model(x_num, x_cat) for model in self.models]
#         return torch.stack(outputs).mean(dim=0)

#     def get_individual_predictions(self, x_num, x_cat):
#         """Get predictions from each model individually for uncertainty estimation."""
#         with torch.no_grad():
#             outputs = [model(x_num, x_cat) for model in self.models]
#         return torch.stack(outputs)  # (n_models, batch_size, n_targets)

#     def expand_categorical_embedding(
#         self, feature_name: str, new_categories: List[str], initialization: str = "mean"
#     ) -> None:
#         """Expand embeddings on all models in the ensemble."""
#         for model in self.models:
#             model.expand_categorical_embedding(
#                 feature_name, new_categories, initialization
#             )


# # --- PHYSICS-INFORMED LOSS ---


# def get_physics_masks(
#     X_cat: torch.Tensor, X_num: torch.Tensor, processor: "DataProcessor"
# ) -> Dict[str, torch.Tensor]:
#     """
#     Generate boolean masks for physics constraints based on batch data.

#     CRITICAL UPDATE:
#     Since X_num is scaled (Z-scores), we must unscale specific columns
#     (like HCI) before applying absolute physical thresholds (e.g. HCI >= 1.3).

#     Args:
#         X_cat: Tensor of categorical indices (batch, n_cat)
#         X_num: Tensor of numeric features (batch, n_num) [SCALED]
#         processor: Fitted DataProcessor instance containing scaler stats

#     Returns:
#         Dictionary of masks for physics constraints
#     """
#     masks = {}
#     device = X_cat.device

#     try:
#         # 1. Regime mask (Near or Mixed)
#         if "Regime" in processor.categorical_features:
#             idx_regime = processor.categorical_features.index("Regime")
#             regime_map = processor.cat_maps["Regime"]

#             # Find indices for 'near' and 'mixed' in the vocabulary
#             near_idx = [i for i, x in enumerate(regime_map) if "near" in x.lower()]
#             mixed_idx = [i for i, x in enumerate(regime_map) if "mixed" in x.lower()]

#             target_regimes = torch.tensor(near_idx + mixed_idx, device=device)

#             # Mask: Is Near or Mixed?
#             masks["is_near_mixed"] = (
#                 torch.isin(X_cat[:, idx_regime], target_regimes).float().unsqueeze(1)
#             )
#         else:
#             masks["is_near_mixed"] = torch.zeros(X_cat.shape[0], 1, device=device)

#         # 2. Mask: High HCI? (HCI >= 1.3)
#         if "HCI" in processor.numeric_features:
#             hci_idx = processor.numeric_features.index("HCI")
#             hci_vals = X_num[:, hci_idx]

#             if (
#                 "HCI" in processor.scalable_features
#                 and hasattr(processor.scaler, "mean_")
#                 and processor.scaler.mean_ is not None
#             ):

#                 scaler_idx = processor.scalable_features.index("HCI")
#                 mean_val = processor.scaler.mean_[scaler_idx]
#                 scale_val = processor.scaler.scale_[scaler_idx]

#                 # Convert to tensors on the correct device
#                 mean_t = torch.tensor(mean_val, device=device, dtype=torch.float32)
#                 scale_t = torch.tensor(scale_val, device=device, dtype=torch.float32)

#                 # Unscale: raw = z_score * std + mean
#                 hci_vals = hci_vals * scale_t + mean_t

#             # Apply threshold on (now potentially raw) values
#             masks["is_high_hci"] = (hci_vals >= 1.3).float().unsqueeze(1)
#         else:
#             masks["is_high_hci"] = torch.zeros(X_cat.shape[0], 1, device=device)

#         # 3. Placeholder Masks for Excipients
#         # (Could be expanded to check actual presence of excipients)
#         masks["has_ionic"] = torch.ones(X_cat.shape[0], 1, device=device)
#         masks["has_sucrose"] = torch.ones(X_cat.shape[0], 1, device=device)
#         masks["has_tween"] = torch.ones(X_cat.shape[0], 1, device=device)

#     except Exception as e:
#         print(f"Warning: Could not build physics masks: {e}")
#         # Fallback to zeros
#         return {
#             k: torch.zeros(X_cat.shape[0], 1, device=device)
#             for k in [
#                 "is_near_mixed",
#                 "is_high_hci",
#                 "has_ionic",
#                 "has_sucrose",
#                 "has_tween",
#             ]
#         }

#     return masks


# def validate_data(
#     X_num: np.ndarray, X_cat: np.ndarray, y: np.ndarray, name: str = "data"
# ) -> bool:
#     """
#     Validate data for NaN and Inf values.

#     Args:
#         X_num: Numeric features
#         X_cat: Categorical features
#         y: Target values
#         name: Name for error messages

#     Returns:
#         True if validation passes

#     Raises:
#         ValueError: If data contains NaN or Inf values
#     """
#     if np.any(np.isnan(X_num)):
#         raise ValueError(f"NaN in {name} numeric features")
#     if np.any(np.isinf(X_num)):
#         raise ValueError(f"Inf in {name} numeric features")
#     if np.any(np.isnan(y)):
#         raise ValueError(f"NaN in {name} targets")
#     return True


# def calculate_sample_weights(y_raw: np.ndarray) -> np.ndarray:
#     """
#     Calculate sample weights based on viscosity values.
#     Emphasizes high viscosity samples which are rare but important.

#     Args:
#         y_raw: Raw target values (n_samples, n_targets)

#     Returns:
#         Sample weights (n_samples,)
#     """
#     # Viscosity_100 is usually the first target column
#     v100 = y_raw[:, 0]

#     # 1. Base weight: Logarithmic (Standard)
#     # This prevents the massive range of values (1 to 1000+) from dominating gradients purely by magnitude
#     weights = 1.0 + np.log1p(v100)

#     # 2. Boost High Viscosity Samples
#     # Samples > 20 cP are rare and exhibit exponential behavior.
#     # We multiply their weight by 5.0 to force the model to fit the steep curve.
#     high_vis_mask = v100 > 20.0
#     weights[high_vis_mask] *= 5.0

#     return weights.astype(np.float32)


# class PhysicsInformedLoss(nn.Module):
#     """
#     Physics-informed loss function incorporating domain knowledge constraints.

#     Combines:
#     1. Standard MSE loss
#     2. Shear-thinning constraint (viscosity should decrease with shear rate)
#     3. Input gradient constraints from domain knowledge
#     """

#     def __init__(
#         self,
#         lambda_shear: float = 1.0,
#         lambda_input: float = 0.1,
#         numeric_cols: Optional[List[str]] = None,
#     ):
#         """
#         Args:
#             lambda_shear: Weight for shear-thinning constraint (output consistency).
#             lambda_input: Weight for input-gradient constraints (Table D rules).
#             numeric_cols: List of numeric column names to identify indices.
#         """
#         super().__init__()
#         self.lambda_shear = lambda_shear
#         self.lambda_input = lambda_input
#         self.numeric_cols = numeric_cols or []

#         # Pre-calculate indices for numeric features if possible
#         self.idx_map = {name: i for i, name in enumerate(self.numeric_cols)}

#     def forward(
#         self,
#         pred: torch.Tensor,
#         target: torch.Tensor,
#         inputs_num: torch.Tensor,
#         masks: Dict[str, torch.Tensor],
#         weights: Optional[torch.Tensor] = None,
#     ) -> torch.Tensor:
#         """
#         Args:
#             pred: Model outputs (batch, n_targets)
#             target: True targets
#             inputs_num: Numeric inputs (batch, n_features). MUST have requires_grad=True.
#             masks: Dictionary containing boolean masks for the batch:
#                    - 'is_near_mixed': (batch, 1) 1 if Regime is Near/Mixed
#                    - 'is_high_hci': (batch, 1) 1 if HCI >= 1.3
#                    - 'has_ionic': (batch, 1) 1 if Salt/Arg/Lys present
#                    - 'has_sucrose': (batch, 1) 1 if Sucrose present
#                    - 'has_tween': (batch, 1) 1 if Tween present
#             weights: Sample weights
#         """
#         # 1. Standard MSE Loss
#         squared_diff = (pred - target) ** 2
#         if weights is not None:
#             if weights.dim() == 1:
#                 weights = weights.unsqueeze(1)
#             mse_loss = (squared_diff * weights).mean()
#         else:
#             mse_loss = squared_diff.mean()

#         # 2. Shear Thinning Constraint (Output Monotonicity)
#         # Viscosity should decrease (or stay same) as shear rate increases (next column)
#         shear_loss = 0.0
#         for i in range(pred.shape[1] - 1):
#             # diff > 0 means Viscosity(High Shear) > Viscosity(Low Shear) -> Violation
#             diff = pred[:, i + 1] - pred[:, i]
#             violation = torch.relu(diff)
#             shear_loss += violation.mean()

#         # 3. Input Gradient Constraints (Table D from PDF)
#         input_loss = 0.0

#         # We need gradients of predictions w.r.t inputs to check sensitivity
#         if self.lambda_input > 0 and inputs_num.requires_grad:
#             # Calculate Gradients
#             grads = torch.autograd.grad(
#                 outputs=pred.sum(),
#                 inputs=inputs_num,
#                 create_graph=True,
#                 retain_graph=True,
#                 only_inputs=True,
#                 allow_unused=True,
#             )[0]

#             # If inputs weren't used in the graph, grads will be None.
#             if grads is not None:
#                 # Constraint A: Ionic Strength
#                 if "Salt_conc" in self.idx_map and "Excipient_conc" in self.idx_map:
#                     idx_s = self.idx_map["Salt_conc"]
#                     idx_e = self.idx_map["Excipient_conc"]
#                     grad_ionic = grads[:, idx_s] + grads[:, idx_e]
#                     mask_a = masks.get("is_near_mixed", 0) * masks.get("has_ionic", 0)
#                     input_loss += (torch.relu(grad_ionic) * mask_a).mean()

#                 # Constraint B: Sucrose
#                 if "Stabilizer_conc" in self.idx_map:
#                     idx_suc = self.idx_map["Stabilizer_conc"]
#                     grad_suc = grads[:, idx_suc]
#                     mask_b = masks.get("has_sucrose", 0)
#                     input_loss += (torch.relu(-grad_suc) * mask_b).mean()

#                 # Constraint C: Tween
#                 if "Surfactant_conc" in self.idx_map:
#                     idx_tw = self.idx_map["Surfactant_conc"]
#                     grad_tw = grads[:, idx_tw]
#                     mask_c = masks.get("is_high_hci", 0) * masks.get("has_tween", 0)
#                     input_loss += (torch.relu(grad_tw) * mask_c).mean()

#         total_loss = (
#             mse_loss
#             + (self.lambda_shear * shear_loss)
#             + (self.lambda_input * input_loss)
#         )
#         return total_loss


# # --- DATA PROCESSOR ---


# class DataProcessor:
#     """
#     Handles all data preprocessing including:
#     - Categorical encoding with vocabulary mapping
#     - Numeric feature scaling
#     - Feature engineering (Regime computation including 'noprotein')
#     - Concentration Splitting (E_low / E_high)
#     - Distance-based trust scores
#     """

#     def __init__(self, allow_new_categories: bool = False):
#         self.cat_maps = {}
#         self.scaler = StandardScaler()
#         self.is_fitted = False
#         self.categorical_features = BASE_CATEGORICAL.copy()
#         self.numeric_features = BASE_NUMERIC.copy()
#         self.allow_new_categories = allow_new_categories
#         self.constant_features = []
#         self.constant_values = {}
#         self.scalable_features = []

#         # [NEW] Track generated features and split indices
#         # Maps original col name (e.g. 'Salt_conc') -> tuple of indices (idx_low, idx_high) in X_num
#         self.split_indices = {}
#         self.generated_feature_names = []

#     def _compute_regime(self, df: pd.DataFrame) -> pd.Series:
#         """
#         Compute interaction regime based on CCI and Protein Class.
#         [UPDATED]: Explicitly saves 'CCI_Score' to the dataframe for inspection.
#         """
#         regime = []

#         # Pre-fetch columns
#         has_p_conc = "Protein_conc" in df.columns
#         has_p_type = "Protein_type" in df.columns

#         # Ensure required columns exist
#         req_cols = ["C_Class", "Buffer_pH", "PI_mean", "Protein_class_type"]
#         missing = [c for c in req_cols if c not in df.columns]

#         if "Protein_class" in df.columns and "Protein_class_type" in missing:
#             df["Protein_class_type"] = df["Protein_class"]
#             missing.remove("Protein_class_type")

#         # --- UPDATE: Save CCI Score to DataFrame ---
#         if not missing:
#             tau = 1.5
#             delta_ph = (df["Buffer_pH"] - df["PI_mean"]).abs()
#             # Assign directly to df
#             df["CCI_Score"] = df["C_Class"] * np.exp(-delta_ph / tau)
#             cci_values = df["CCI_Score"]
#         else:
#             df["CCI_Score"] = np.nan
#             cci_values = pd.Series([np.nan] * len(df), index=df.index)
#         # -------------------------------------------

#         for i in range(len(df)):
#             row = df.iloc[i]

#             # 1. DETECT NO PROTEIN
#             is_no_protein = False
#             if has_p_type:
#                 p_type = str(row.get("Protein_type", "")).lower()
#                 if p_type in ["none", "buffer", "nan", "null"]:
#                     is_no_protein = True
#             if has_p_conc:
#                 if row.get("Protein_conc", 0.0) <= 0.0:
#                     is_no_protein = True

#             if is_no_protein:
#                 regime.append("noprotein")
#                 continue

#             # 2. CALCULATE REGIME
#             if missing:
#                 regime.append("unknown")
#                 continue

#             cci = cci_values.iloc[i]
#             p_class = str(df["Protein_class_type"].iloc[i]).lower()

#             if pd.isna(cci):
#                 regime.append("unknown")
#                 continue

#             r = "unknown"
#             # Logic from Table B
#             if "igg1" in p_class:
#                 if cci >= 0.90:
#                     r = "near"
#                 elif cci >= 0.50:
#                     r = "mixed"
#                 else:
#                     r = "far"
#             elif "igg4" in p_class:
#                 if cci >= 0.80:
#                     r = "near"
#                 elif cci >= 0.40:
#                     r = "mixed"
#                 else:
#                     r = "far"
#             elif "fc-fusion" in p_class or "linker" in p_class:
#                 if cci >= 0.70:
#                     r = "near"
#                 elif cci >= 0.40:
#                     r = "mixed"
#                 else:
#                     r = "far"
#             elif "bispecific" in p_class or "adc" in p_class:
#                 if cci >= 0.80:
#                     r = "near"
#                 elif cci >= 0.45:
#                     r = "mixed"
#                 else:
#                     r = "far"
#             elif "bsa" in p_class or "polyclonal" in p_class:
#                 if cci >= 0.70:
#                     r = "near"
#                 elif cci >= 0.40:
#                     r = "mixed"
#                 else:
#                     r = "far"
#             else:
#                 if cci >= 0.90:
#                     r = "near"
#                 elif cci >= 0.50:
#                     r = "mixed"
#                 else:
#                     r = "far"

#             regime.append(r)

#         return pd.Series(regime, index=df.index)

#     def _construct_numeric_matrix(
#         self, df: pd.DataFrame, is_fitting: bool = False
#     ) -> Tuple[np.ndarray, List[str]]:
#         """
#         [NEW] Internal helper to build the numeric feature matrix.
#         Handles the splitting of specific concentration columns into Low/High features.
#         """
#         feature_arrays = []
#         gen_names = []
#         new_split_indices = {}
#         current_idx = 0

#         for col in self.numeric_features:
#             # Check if this column requires splitting (defined in CONC_TYPE_PAIRS)
#             if col in CONC_TYPE_PAIRS:
#                 type_col = CONC_TYPE_PAIRS[col]

#                 # Get numeric values (fill NaNs with 0)
#                 if col in df.columns:
#                     conc_vals = df[col].fillna(0.0).values
#                 else:
#                     conc_vals = np.zeros(len(df))

#                 # Get type strings for threshold lookup
#                 if type_col in df.columns:
#                     type_vals = (
#                         df[type_col].fillna("none").astype(str).str.lower().values
#                     )
#                 else:
#                     type_vals = np.full(len(df), "none")

#                 # --- THRESHOLD LOGIC ---
#                 # Default threshold is arbitrarily high so E_low = conc, E_high = 0 if type unknown
#                 thresh_vals = np.full(len(df), 999999.0)

#                 # Vectorized-ish lookup
#                 for k, t_val in CONC_THRESHOLDS.items():
#                     # Check if 'k' (e.g. 'sucrose') is in the type string (e.g. 'sucrose')
#                     # List comprehension used for substring matching
#                     mask = np.array([k in str(v) for v in type_vals])
#                     thresh_vals[mask] = t_val

#                 # --- SPLIT CALCULATION ---
#                 # E_low = min(E, T)
#                 E_low = np.minimum(conc_vals, thresh_vals)
#                 # E_high = max(E - T, 0)
#                 E_high = np.maximum(conc_vals - thresh_vals, 0.0)

#                 feature_arrays.append(E_low)
#                 feature_arrays.append(E_high)

#                 gen_names.append(f"{col}_low")
#                 gen_names.append(f"{col}_high")

#                 # Record indices for the Model to use later
#                 new_split_indices[col] = (current_idx, current_idx + 1)
#                 current_idx += 2

#             else:
#                 # --- STANDARD PROCESSING ---
#                 if col in self.constant_features:
#                     vals = np.full(len(df), self.constant_values[col])
#                 elif col in df.columns:
#                     vals = df[col].fillna(0.0).values
#                 else:
#                     vals = np.zeros(len(df))

#                 feature_arrays.append(vals)
#                 gen_names.append(col)
#                 current_idx += 1

#         # Stack all arrays horizontally
#         X_combined = np.column_stack(feature_arrays)

#         if is_fitting:
#             self.generated_feature_names = gen_names
#             self.split_indices = new_split_indices

#         return X_combined, gen_names

#     def fit_transform(self, df: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
#         """Fit processor and transform data."""
#         # 1. Fit Categorical (Regime vocabulary added here)
#         self._fit_categorical(df)

#         # 2. Fit Numeric (with Splitting)
#         # Identify constant features first based on raw data
#         for col in self.numeric_features:
#             if col in df.columns:
#                 unique_vals = df[col].dropna().unique()
#                 if len(unique_vals) == 1:
#                     self.constant_features.append(col)
#                     self.constant_values[col] = unique_vals[0]

#         # Construct the full matrix (handles splitting)
#         X_num_full, _ = self._construct_numeric_matrix(df, is_fitting=True)

#         # Fit Scaler on the EXPANDED matrix
#         self.scaler.fit(X_num_full)

#         self.is_fitted = True
#         return self.transform(df)

#     def transform(self, df: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
#         """Transform data using fitted processor."""
#         if not self.is_fitted:
#             raise ValueError("Processor must be fitted first")

#         X_cat = self._transform_categorical(df)

#         # Construct numeric matrix (using fitted split logic)
#         X_num_raw, _ = self._construct_numeric_matrix(df, is_fitting=False)

#         # Apply scaling
#         X_num = self.scaler.transform(X_num_raw)

#         return X_num, X_cat

#     def _fit_categorical(self, df: pd.DataFrame) -> None:
#         """Build categorical vocabularies."""
#         # Ensure Regime is in the list
#         if "Regime" not in self.categorical_features:
#             self.categorical_features.append("Regime")

#         for col in self.categorical_features:
#             if col == "Regime":
#                 # Preset Regime vocabulary including new 'noprotein'
#                 self.cat_maps["Regime"] = [
#                     "far",
#                     "mixed",
#                     "near",
#                     "noprotein",
#                     "unknown",
#                 ]
#                 continue

#             if col not in df.columns:
#                 print(f"Warning: {col} not in dataframe, skipping")
#                 self.cat_maps[col] = ["none"]
#                 continue

#             unique_vals = df[col].dropna().unique().tolist()
#             if "none" not in unique_vals:
#                 unique_vals.insert(0, "none")

#             self.cat_maps[col] = unique_vals

#     def _transform_categorical(self, df: pd.DataFrame) -> np.ndarray:
#         """Transform categorical features to indices."""
#         cat_data = []

#         # Pre-compute regimes to handle 'noprotein' logic
#         regime_series = self._compute_regime(df)

#         for col in self.categorical_features:
#             if col == "Regime":
#                 indices = [
#                     (
#                         self.cat_maps["Regime"].index(val)
#                         if val in self.cat_maps["Regime"]
#                         else self.cat_maps["Regime"].index("unknown")
#                     )
#                     for val in regime_series
#                 ]
#             else:
#                 if col not in df.columns:
#                     indices = [0] * len(df)
#                 else:
#                     values = df[col].fillna("none").astype(str).str.lower()
#                     indices = []
#                     for val in values:
#                         if val in self.cat_maps[col]:
#                             indices.append(self.cat_maps[col].index(val))
#                         else:
#                             if self.allow_new_categories:
#                                 self.cat_maps[col].append(val)
#                                 indices.append(len(self.cat_maps[col]) - 1)
#                             else:
#                                 indices.append(0)  # 'none'

#             cat_data.append(indices)

#         return np.array(cat_data, dtype=np.int64).T

#     def compute_distance(self, X_num: np.ndarray) -> np.ndarray:
#         """Compute trust distance."""
#         if not hasattr(self.scaler, "mean_") or self.scaler.mean_ is None:
#             return np.zeros(X_num.shape[0])
#         distances = np.linalg.norm(X_num, axis=1)
#         return distances

#     def detect_new_categories(self, df: pd.DataFrame) -> Dict[str, List[str]]:
#         """Detect categories that weren't seen during fitting."""
#         new_cats = {}
#         for col in self.categorical_features:
#             if col == "Regime" or col not in df.columns:
#                 continue

#             df_vals = set(df[col].dropna().astype(str).str.lower().unique())
#             known_vals = set(self.cat_maps[col])
#             unseen = df_vals - known_vals

#             if unseen:
#                 new_cats[col] = list(unseen)
#         return new_cats

#     def add_categories(self, feature_name: str, new_categories: List[str]) -> None:
#         """Add new categories to vocabulary."""
#         if feature_name not in self.cat_maps:
#             raise ValueError(f"Feature {feature_name} not found")

#         for cat in new_categories:
#             if cat not in self.cat_maps[feature_name]:
#                 self.cat_maps[feature_name].append(cat)
#         print(f"Added {len(new_categories)} categories to {feature_name}")

#     def get_vocab_sizes(self) -> Dict[str, int]:
#         if not self.is_fitted:
#             raise ValueError("Processor must be fitted first")
#         return {col: len(self.cat_maps[col]) for col in self.categorical_features}

#     def save(self, path: str) -> None:
#         state = {
#             "cat_maps": self.cat_maps,
#             "scaler": self.scaler,
#             "is_fitted": self.is_fitted,
#             "categorical_features": self.categorical_features,
#             "numeric_features": self.numeric_features,
#             "allow_new_categories": self.allow_new_categories,
#             "constant_features": self.constant_features,
#             "constant_values": self.constant_values,
#             "scalable_features": self.scalable_features,
#             # [NEW] Persist split metadata
#             "split_indices": self.split_indices,
#             "generated_feature_names": self.generated_feature_names,
#         }
#         with open(path, "wb") as f:
#             pickle.dump(state, f)

#     def load(self, path: str) -> None:
#         with open(path, "rb") as f:
#             state = pickle.load(f)

#         self.cat_maps = state["cat_maps"]
#         self.scaler = state["scaler"]
#         self.is_fitted = state["is_fitted"]
#         self.categorical_features = state.get(
#             "categorical_features", BASE_CATEGORICAL.copy()
#         )
#         self.numeric_features = state.get("numeric_features", BASE_NUMERIC.copy())
#         self.allow_new_categories = state.get("allow_new_categories", False)
#         self.constant_features = state.get("constant_features", [])
#         self.constant_values = state.get("constant_values", {})
#         self.scalable_features = state.get(
#             "scalable_features", self.numeric_features.copy()
#         )

#         # [NEW] Load split metadata
#         self.split_indices = state.get("split_indices", {})
#         self.generated_feature_names = state.get("generated_feature_names", [])


# # --- MODEL EVALUATION ---


# def evaluate_model(
#     model: nn.Module,
#     processor: DataProcessor,
#     data_path: str,
#     output_prefix: str = "evaluation",
# ) -> Dict:
#     """
#     Comprehensive model evaluation with metrics and predictions.

#     Args:
#         model: Trained model (can be single or ensemble)
#         processor: Fitted data processor
#         data_path: Path to evaluation data CSV
#         output_prefix: Prefix for output files

#     Returns:
#         Dictionary containing evaluation metrics
#     """
#     print("\n" + "=" * 70)
#     print("Model Evaluation on Full Dataset")
#     print("=" * 70)

#     df = pd.read_csv(data_path)
#     df_clean = clean(
#         df,
#         numeric_cols=BASE_NUMERIC,
#         categorical_cols=BASE_CATEGORICAL,
#         target_cols=TARGETS,
#     )

#     print(f"\nEvaluating on {len(df_clean)} samples")
#     X_num, X_cat = processor.transform(df_clean)

#     # Calculate Trust Distance
#     trust_distances = processor.compute_distance(X_num)

#     y_true = df_clean[TARGETS].values
#     y_log = log_transform_targets(y_true)

#     X_num_t, X_cat_t, y_log_t = to_tensors(X_num, X_cat, y_log)

#     model.eval()
#     with torch.no_grad():
#         y_log_pred = model(X_num_t, X_cat_t).numpy()
#     y_pred = inverse_log_transform(y_log_pred)

#     # Compute metrics
#     metrics = {}
#     print("\nPer-Target Metrics:")
#     print("-" * 70)

#     for i, target_name in enumerate(TARGETS):
#         y_true_target = y_true[:, i]
#         y_pred_target = y_pred[:, i]

#         mse = mean_squared_error(y_true_target, y_pred_target)
#         rmse = np.sqrt(mse)
#         mae = mean_absolute_error(y_true_target, y_pred_target)
#         r2 = r2_score(y_true_target, y_pred_target)

#         mask = y_true_target != 0
#         if mask.sum() > 0:
#             mape = (
#                 np.mean(
#                     np.abs(
#                         (y_true_target[mask] - y_pred_target[mask])
#                         / y_true_target[mask]
#                     )
#                 )
#                 * 100
#             )
#         else:
#             mape = np.nan

#         metrics[target_name] = {
#             "MSE": mse,
#             "RMSE": rmse,
#             "MAE": mae,
#             "R2": r2,
#             "MAPE": mape,
#         }

#         print(f"\n{target_name}:")
#         print(f"  MSE:  {mse:.4f}")
#         print(f"  RMSE: {rmse:.4f}")
#         print(f"  MAE:  {mae:.4f}")
#         print(f"  R²:   {r2:.4f}")
#         if not np.isnan(mape):
#             print(f"  MAPE: {mape:.2f}%")

#     print("\nOverall Metrics (averaged across targets):")
#     print("-" * 70)
#     overall_metrics = {
#         "MSE": np.mean([m["MSE"] for m in metrics.values()]),
#         "RMSE": np.mean([m["RMSE"] for m in metrics.values()]),
#         "MAE": np.mean([m["MAE"] for m in metrics.values()]),
#         "R2": np.mean([m["R2"] for m in metrics.values()]),
#         "MAPE": np.nanmean([m["MAPE"] for m in metrics.values()]),
#     }

#     for metric_name, value in overall_metrics.items():
#         if metric_name == "MAPE":
#             print(f"  {metric_name}: {value:.2f}%")
#         else:
#             print(f"  {metric_name}: {value:.4f}")

#     # Save detailed results
#     results_df = df_clean.copy()
#     results_df["Trust_Distance"] = trust_distances

#     for i, target_name in enumerate(TARGETS):
#         results_df[f"{target_name}_actual"] = y_true[:, i]
#         results_df[f"{target_name}_predicted"] = y_pred[:, i]
#         results_df[f"{target_name}_error"] = y_true[:, i] - y_pred[:, i]

#         mask = y_true[:, i] != 0
#         pct_error = np.zeros(len(y_true))
#         pct_error[mask] = (
#             (y_true[:, i][mask] - y_pred[:, i][mask]) / y_true[:, i][mask] * 100
#         )
#         results_df[f"{target_name}_pct_error"] = pct_error

#     timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
#     results_file = f"{output_prefix}_predictions_{timestamp}.csv"
#     results_df.to_csv(results_file, index=False)
#     print(f"\nSaved predictions to: {results_file}")

#     metrics_file = f"{output_prefix}_metrics_{timestamp}.json"
#     all_metrics = {
#         "per_target": metrics,
#         "overall": overall_metrics,
#         "n_samples": len(df_clean),
#     }
#     with open(metrics_file, "w") as f:
#         json.dump(all_metrics, f, indent=2)
#     print(f"Saved metrics to: {metrics_file}")

#     return all_metrics


# # --- MODEL MANAGEMENT ---


# def expand_processor_and_model(
#     processor: DataProcessor,
#     model: Model,
#     feature_name: str,
#     new_categories: List[str],
#     initialization: str = "mean",
# ) -> None:
#     """Expand both processor and model for new categories."""
#     processor.add_categories(feature_name, new_categories)
#     model.expand_categorical_embedding(feature_name, new_categories, initialization)


# class ResidualAdapter(nn.Module):
#     """
#     Residual Adapter network for domain adaptation.
#     Added to core.py to ensure availability across modules.
#     """

#     def __init__(self, numeric_dim, cat_dims, embed_dim=16):
#         super().__init__()
#         self.num_proj = nn.Linear(numeric_dim, embed_dim)
#         self.embeddings = nn.ModuleList([nn.Embedding(n, embed_dim) for n in cat_dims])
#         # Output dim is len(TARGETS) imported from config section above
#         self.net = nn.Sequential(
#             nn.Linear(embed_dim * (len(cat_dims) + 1), 64),
#             nn.ReLU(),
#             nn.Linear(64, 32),
#             nn.ReLU(),
#             nn.Linear(32, len(TARGETS)),
#         )

#     def forward(self, x_num, x_cat):
#         embs = [emb(x_cat[:, i]) for i, emb in enumerate(self.embeddings)]
#         num_emb = self.num_proj(x_num)
#         x = torch.cat(embs + [num_emb], dim=1)
#         return self.net(x)


# def attach_adapter(
#     model: Model,
#     adapter_state_dict: Dict,
#     gating_thresholds: Optional[Dict[str, int]] = None,
# ) -> nn.Module:
#     """
#     Reconstructs an adapter and attaches it with dynamic gating.

#     Args:
#         model: The base model
#         adapter_state_dict: Weights for the adapter
#         gating_thresholds: Dict mapping feature names to their "base" vocab size.
#                            Indices >= this size trigger the adapter.
#     """
#     # 1. Inspect model dimensions (same as before)
#     cat_dims = [len(m) for m in model.cat_maps.values()]
#     total_in = model.base[0].in_features
#     total_emb = sum(e.embedding_dim for e in model.embeddings)
#     numeric_dim = total_in - total_emb

#     # 2. Initialize Adapter
#     adapter = ResidualAdapter(numeric_dim, cat_dims, embed_dim=16)
#     adapter.load_state_dict(adapter_state_dict)
#     adapter.eval()

#     # 3. Prepare Gating Logic
#     original_forward = model.forward

#     # If no thresholds provided, fallback to "always on" or legacy "last protein" logic
#     # But strictly speaking, for this request, we want the threshold logic.
#     checks = []
#     if gating_thresholds:
#         for feat, threshold in gating_thresholds.items():
#             if feat in model.cat_feature_names:
#                 idx = model.cat_feature_names.index(feat)
#                 checks.append((idx, threshold))
#     else:
#         # Fallback: Try to guess or warn.
#         # For safety, if no thresholds provided, we might assume the adapter
#         # should active for the *very last* item in every list (legacy behavior approximation)
#         print(
#             "  [Core] Warning: No gating_thresholds provided. Adapter will default to Protein_type gating."
#         )
#         try:
#             p_idx = model.cat_feature_names.index("Protein_type")
#             p_thresh = len(model.cat_maps["Protein_type"]) - 1  # Only last one
#             checks.append((p_idx, p_thresh))
#         except ValueError:
#             pass

#     def new_forward(x_n, x_c, return_features=False):
#         if return_features:
#             base, feats = original_forward(x_n, x_c, return_features=True)
#         else:
#             base = original_forward(x_n, x_c)

#         adapt = adapter(x_n, x_c)

#         # Dynamic Masking
#         mask = torch.zeros(x_c.size(0), 1, dtype=torch.bool, device=x_c.device)
#         for col_idx, cutoff in checks:
#             is_new = x_c[:, col_idx] >= cutoff
#             mask = mask | is_new.unsqueeze(1)

#         res = base + (adapt * mask.float())

#         if return_features:
#             return res, feats
#         return res

#     model.forward = new_forward
#     print("  [Core] Adapter attached with thresholds.")
#     return adapter


# # --- MODEL MANAGEMENT ---


# def save_model_checkpoint(
#     model: nn.Module,
#     processor: DataProcessor,
#     best_params: Dict,
#     filepath: str,
#     adapter: Optional[nn.Module] = None,
# ) -> None:
#     """
#     Save model checkpoint with processor state (including split indices),
#     hyperparameters, and optional adapter.
#     """
#     checkpoint = {
#         "model_state_dict": model.state_dict(),
#         "best_params": best_params,
#         # Processor State
#         "cat_maps": processor.cat_maps,
#         "numeric_features": processor.numeric_features,
#         "categorical_features": processor.categorical_features,
#         "constant_values": processor.constant_values,
#         "scalable_features": processor.scalable_features,
#         # [NEW] Persist Split Metadata
#         "split_indices": processor.split_indices,
#         "generated_feature_names": processor.generated_feature_names,
#         "scaler_state": {
#             "mean_": processor.scaler.mean_,
#             "scale_": processor.scaler.scale_,
#             "n_features_in_": getattr(processor.scaler, "n_features_in_", 0),
#         },
#     }

#     # --- SAVE ADAPTER STATE ---
#     if adapter is not None:
#         checkpoint["adapter_state_dict"] = adapter.state_dict()
#         checkpoint["has_adapter"] = True
#     else:
#         # Check if the model itself has a detached state dict stored
#         if (
#             hasattr(model, "adapter_state_dict")
#             and model.adapter_state_dict is not None
#         ):
#             checkpoint["adapter_state_dict"] = model.adapter_state_dict
#             checkpoint["has_adapter"] = True
#         else:
#             checkpoint["has_adapter"] = False

#     torch.save(checkpoint, filepath)
#     print(
#         f"Saved checkpoint to: {filepath} (Adapter saved: {checkpoint['has_adapter']})"
#     )


# def load_model_checkpoint(
#     filepath: str, device: str = "cpu"
# ) -> Tuple[Model, DataProcessor, Dict]:
#     """
#     Load model checkpoint.
#     Correctly initializes Model with split_indices and expanded numeric dimensions.
#     """
#     checkpoint = torch.load(filepath, map_location=device, weights_only=False)

#     # Reconstruct processor
#     processor = DataProcessor()
#     processor.cat_maps = checkpoint.get("cat_maps", {})
#     processor.numeric_features = checkpoint.get("numeric_features", [])
#     processor.categorical_features = checkpoint.get("categorical_features", [])
#     processor.constant_values = checkpoint.get("constant_values", {})
#     processor.scalable_features = checkpoint.get(
#         "scalable_features", processor.numeric_features.copy()
#     )
#     processor.constant_features = list(processor.constant_values.keys())

#     # [NEW] Restore Split Metadata
#     processor.split_indices = checkpoint.get("split_indices", {})
#     processor.generated_feature_names = checkpoint.get("generated_feature_names", [])

#     processor.allow_new_categories = False
#     processor.is_fitted = True

#     # Rebuild scaler
#     scaler_state = checkpoint.get("scaler_state", None)
#     if scaler_state is not None:
#         processor.scaler = StandardScaler()
#         processor.scaler.mean_ = np.asarray(scaler_state["mean_"], dtype=np.float64)
#         processor.scaler.scale_ = np.asarray(scaler_state["scale_"], dtype=np.float64)
#         processor.scaler.n_features_in_ = int(scaler_state["n_features_in_"])
#         if "feature_names_in_" in scaler_state:
#             processor.scaler.feature_names_in_ = np.array(
#                 scaler_state["feature_names_in_"]
#             )

#         # [CRITICAL] Determine numeric_dim from the SCALER, not the raw feature list.
#         # This accounts for the extra columns created by splitting (E_low, E_high).
#         actual_numeric_dim = len(processor.scaler.mean_)
#     else:
#         processor.scaler = None
#         actual_numeric_dim = len(processor.numeric_features)  # Fallback

#     # Reconstruct model
#     best_params = checkpoint["best_params"]
#     hidden_size = best_params["hidden_size"]
#     n_layers = best_params["n_layers"]
#     hidden_sizes = [hidden_size] * n_layers

#     model = Model(
#         cat_maps=processor.cat_maps,
#         numeric_dim=actual_numeric_dim,  # [UPDATED] Uses actual input dimension
#         out_dim=len(TARGETS),
#         hidden_sizes=hidden_sizes,
#         dropout=best_params["dropout"],
#         split_indices=processor.split_indices,  # [UPDATED] Pass split map to Model
#     )

#     # Handle Ensemble Keys
#     state_dict = checkpoint["model_state_dict"]
#     first_key = next(iter(state_dict.keys()))
#     if first_key.startswith("models."):
#         print(
#             "  [INFO] Detected Ensemble checkpoint. Extracting weights for single Model..."
#         )
#         new_state_dict = {}
#         for k, v in state_dict.items():
#             if k.startswith("models.0."):
#                 new_key = k.replace("models.0.", "")
#                 new_state_dict[new_key] = v
#         state_dict = new_state_dict

#     model.load_state_dict(state_dict)
#     model.to(device)

#     # Attach adapter state dict to model for downstream use
#     if "adapter_state_dict" in checkpoint:
#         model.adapter_state_dict = checkpoint["adapter_state_dict"]
#         print(f"  [INFO] Adapter state found and attached to model.adapter_state_dict")
#     else:
#         model.adapter_state_dict = None

#     print(f"Loaded checkpoint from: {filepath}")

#     return model, processor, best_params
import json
import pickle
import warnings
from datetime import datetime
from typing import Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler

# --- CONFIGURATION ---
BASE_CATEGORICAL = [
    "Protein_type",
    "Protein_class_type",
    "Buffer_type",
    "Salt_type",
    "Stabilizer_type",
    "Surfactant_type",
    "Excipient_type",
]

BASE_NUMERIC = [
    "MW",
    "Protein_conc",
    "Temperature",
    "Buffer_pH",
    "Buffer_conc",
    "Salt_conc",
    "Stabilizer_conc",
    "Surfactant_conc",
    "Excipient_conc",
    "kP",
    "C_Class",
    "HCI",
]

TARGETS = [
    "Viscosity_100",
    "Viscosity_1000",
    "Viscosity_10000",
    "Viscosity_100000",
    "Viscosity_15000000",
]

# --- CONCENTRATION THRESHOLDS (New) ---
# Units assumed to match input data (e.g. mM for salts, M for sugars, % for surfactants)
CONC_THRESHOLDS = {
    # Salts / Excipients (mM)
    "arginine": 150.0,
    "lysine": 100.0,
    "proline": 200.0,
    "nacl": 150.0,
    # Surfactants (%)
    "tween": 0.01,
    "polysorbate": 0.01,
    # Stabilizers (M - assuming 0.2M inputs)
    "sucrose": 200.0,  # Assuming inputs are mM. If M, change to 0.2
    "trehalose": 200.0,  # Assuming inputs are mM. If M, change to 0.2
}

# --- PHYSICS PRIORS ---
EXCIPIENT_PRIORS = {
    # Format: (Protein_Class, Regime): {Excipient_Name: Effect_Value}
    # --- SPECIAL REGIME: NO PROTEIN ---
    ("noprotein", "noprotein"): {
        "nacl": 0.1,
        "arginine": 0.1,
        "lysine": 0.1,
        "proline": 0.1,
        "stabilizer": 1.0,  # Generalized from sucrose/trehalose
        "tween": 0.1,
    },
    # --- IgG1 ---
    ("mab_igg1", "near"): {
        "arginine": -2,
        "lysine": -1,
        "nacl": -1,
        "proline": 0,
        "stabilizer": 1,
        "tween": -1,
    },
    ("mab_igg1", "mixed"): {
        "arginine": -1,
        "lysine": -1,
        "nacl": -1,
        "proline": -1,
        "stabilizer": 1,
        "tween": -1,
    },
    ("mab_igg1", "far"): {
        "arginine": 0,
        "lysine": -1,
        "nacl": -1,
        "proline": -1,
        "stabilizer": 1,
        "tween": -1,
    },
    # --- IgG4 ---
    ("mab_igg4", "near"): {
        "arginine": -2,
        "lysine": -1,
        "nacl": -1,
        "proline": 0,
        "stabilizer": 1,
        "tween": -1,
    },
    ("mab_igg4", "mixed"): {
        "arginine": -2,
        "lysine": -1,
        "nacl": -1,
        "proline": -1,
        "stabilizer": 1,
        "tween": -1,
    },
    ("mab_igg4", "far"): {
        "arginine": -1,
        "lysine": -1,
        "nacl": -1,
        "proline": -1,
        "stabilizer": 1,
        "tween": -1,
    },
    # --- Fc-Fusion ---
    ("fc-fusion", "near"): {
        "arginine": -1,
        "lysine": -1,
        "nacl": -1,
        "proline": -1,
        "stabilizer": 1,
        "tween": -2,
    },
    ("fc-fusion", "mixed"): {
        "arginine": -1,
        "lysine": 0,
        "nacl": 0,
        "proline": -2,
        "stabilizer": 1,
        "tween": -2,
    },
    ("fc-fusion", "far"): {
        "arginine": 0,
        "lysine": 0,
        "nacl": 0,
        "proline": -2,
        "stabilizer": 1,
        "tween": -2,
    },
    # --- Bispecific ---
    ("bispecific", "near"): {
        "arginine": -2,
        "lysine": -1,
        "nacl": -1,
        "proline": 0,
        "stabilizer": 1,
        "tween": -1,
    },
    ("bispecific", "mixed"): {
        "arginine": -1,
        "lysine": 0,
        "nacl": 0,
        "proline": -1,
        "stabilizer": 1,
        "tween": -2,
    },
    ("bispecific", "far"): {
        "arginine": 0,
        "lysine": 0,
        "nacl": 0,
        "proline": -1,
        "stabilizer": 1,
        "tween": -2,
    },
    # --- Other/Fallback ---
    ("other", "near"): {
        "arginine": -1,
        "lysine": -1,
        "nacl": -1,
        "proline": 0,
        "stabilizer": 1,
        "tween": 0,
    },
    ("other", "mixed"): {
        "arginine": 0,
        "lysine": 0,
        "nacl": 0,
        "proline": -1,
        "stabilizer": 1,
        "tween": 0,
    },
    ("other", "far"): {
        "arginine": 0,
        "lysine": 0,
        "nacl": 0,
        "proline": -1,
        "stabilizer": 1,
        "tween": 0,
    },
    # POLYCLONAL
    ("polyclonal", "near"): {
        "arginine": -1,
        "lysine": -1,
        "nacl": -1,
        "proline": 0,
        "stabilizer": 1,
        "tween": 0,
    },
    ("polyclonal", "mixed"): {
        "arginine": 0,
        "lysine": 0,
        "nacl": 0,
        "proline": -1,
        "stabilizer": 1,
        "tween": 0,
    },
    ("polyclonal", "far"): {
        "arginine": 0,
        "lysine": 0,
        "nacl": 0,
        "proline": -1,
        "stabilizer": 1,
        "tween": 0,
    },
}

# Map specific column names to the generic types in the Prior Table
EXCIPIENT_TYPE_MAPPING = {
    "Salt_type": ["nacl"],
    "Excipient_type": ["arginine", "lysine", "proline"],
    "Stabilizer_type": ["sucrose", "trehalose"],
    "Surfactant_type": ["tween", "polysorbate"],
}

# Map conc columns to type columns for splitting logic
CONC_TYPE_PAIRS = {
    "Salt_conc": "Salt_type",
    "Stabilizer_conc": "Stabilizer_type",
    "Surfactant_conc": "Surfactant_type",
    "Excipient_conc": "Excipient_type",
}

# --- DATA UTILITIES ---


def clean(
    df: pd.DataFrame,
    numeric_cols: List[str],
    categorical_cols: List[str],
    target_cols: Optional[List[str]] = None,
) -> pd.DataFrame:
    """Clean and preprocess dataframe."""
    df_clean = df.copy()
    bad_str = {"nan", "none", "null", "", "na", "n/a"}

    for col in df_clean.columns:
        if df_clean[col].dtype == object:
            df_clean[col] = (
                df_clean[col]
                .astype(str)
                .str.strip()
                .str.lower()
                .replace(bad_str, np.nan)
            )

    conc_cols = [c for c in numeric_cols if "conc" in c.lower()]
    phys_cols = [c for c in numeric_cols if c not in conc_cols]

    for col in numeric_cols:
        df_clean[col] = pd.to_numeric(df_clean[col], errors="coerce")

    df_clean[conc_cols] = df_clean[conc_cols].fillna(0.0)

    for col in phys_cols:
        if col in df_clean.columns:
            median_val = df_clean[col].median()
            if pd.isna(median_val):
                median_val = 0
            df_clean[col] = df_clean[col].fillna(median_val)

    for col in categorical_cols:
        df_clean[col] = df_clean[col].replace({np.nan: "none"})

    if target_cols:
        for col in target_cols:
            df_clean[col] = pd.to_numeric(df_clean[col], errors="coerce")
        df_clean = df_clean.dropna(subset=target_cols)
        for col in target_cols:
            df_clean = df_clean[df_clean[col] > 0]

    return df_clean


def log_transform_targets(y: np.ndarray) -> np.ndarray:
    return np.log10(y + 1e-8)


def inverse_log_transform(y_log: np.ndarray) -> np.ndarray:
    return 10**y_log - 1e-8


def to_tensors(X_num, X_cat, y=None, weights=None):
    tensors = [
        torch.tensor(X_num, dtype=torch.float32),
        torch.tensor(X_cat, dtype=torch.long),
    ]
    if y is not None:
        tensors.append(torch.tensor(y, dtype=torch.float32))
    if weights is not None:
        tensors.append(torch.tensor(weights, dtype=torch.float32))
    return tuple(tensors)


class LearnablePhysicsPrior(nn.Module):
    """
    Implements the learnable weighted physics prior logic.
    Scores are initialized by the Model class.
    """

    def __init__(self, n_classes, n_regimes, n_excipients):
        super().__init__()
        # Buffer for static scores (initialized by Model._init_static_priors)
        self.register_buffer(
            "static_scores", torch.zeros(n_classes, n_regimes, n_excipients)
        )

        # Learnable parameters
        self.delta = nn.Parameter(torch.zeros(n_classes, n_regimes, n_excipients))
        self.w_L = nn.Parameter(torch.ones(n_classes, n_regimes, n_excipients) * 0.5)
        self.w_H = nn.Parameter(torch.ones(n_classes, n_regimes, n_excipients) * 1.0)

    def forward(self, p_idx, r_idx, e_idx, e_low_norm, e_high_norm):
        # 1. Fetch parameters
        score = self.static_scores[p_idx, r_idx, e_idx]
        d = torch.clamp(self.delta[p_idx, r_idx, e_idx], min=-2.0, max=2.0)
        wl = self.w_L[p_idx, r_idx, e_idx]
        wh = self.w_H[p_idx, r_idx, e_idx]

        # 2. Compute components
        # SAFE SQUEEZE: Use view(-1) to ensure (Batch, 1) -> (Batch,) even if Batch=1
        el = e_low_norm.view(-1)
        eh = e_high_norm.view(-1)

        base_term = score + d
        conc_term = (wl * el) + (wh * eh)

        # 3. Final calculation
        result = base_term * conc_term

        # 4. Pack ALL details for inspection
        details = {
            "static_score": score,
            "delta": d,
            "w_L": wl,
            "w_H": wh,
            "e_low_norm": el,
            "e_high_norm": eh,
            "base_term": base_term,
            "conc_term": conc_term,
            "result": result,
        }

        # result must be (Batch, 1) for broadcasting in Model.forward
        return result.unsqueeze(1), details


class EmbeddingDropout(nn.Module):
    """Drop entire embedding vectors, not individual dimensions."""

    def __init__(self, p: float):
        super().__init__()
        self.p = p

    def forward(self, x):
        if not self.training or self.p == 0:
            return x
        mask = (torch.rand(x.size(0), 1, device=x.device) > self.p).float()
        return x * mask


class ResidualBlock(nn.Module):
    def __init__(self, dim, dropout):
        super().__init__()
        self.fc = nn.Linear(dim, dim)
        self.norm = nn.LayerNorm(dim)
        self.act = nn.ReLU()
        self.drop = nn.Dropout(dropout)

    def forward(self, x):
        residual = x
        x = self.fc(x)
        x = self.norm(x)
        x = self.act(x)
        x = self.drop(x)
        return x + residual


class Model(nn.Module):
    def __init__(
        self,
        cat_maps: Dict,
        numeric_dim: int,
        out_dim: int,
        hidden_sizes: List[int],
        dropout: float,
        split_indices: Dict[str, Tuple[int, int]] = None,
    ):
        super().__init__()
        self.cat_feature_names = list(cat_maps.keys())
        self.cat_maps = {k: list(v) for k, v in cat_maps.items()}
        self.split_indices = split_indices or {}

        # 1. Store indices of "none" for robust masking
        self.none_indices = {}
        for col, categories in self.cat_maps.items():
            none_idx = -1
            for candidate in ["none", "nan", "null", "n/a"]:
                if candidate in categories:
                    none_idx = categories.index(candidate)
                    break
            self.none_indices[col] = none_idx

        # Indices
        self.p_class_idx = (
            self.cat_feature_names.index("Protein_class_type")
            if "Protein_class_type" in self.cat_feature_names
            else -1
        )
        self.regime_idx = (
            self.cat_feature_names.index("Regime")
            if "Regime" in self.cat_feature_names
            else -1
        )

        self.emb_drop = EmbeddingDropout(0.05)

        # Embeddings
        self.embeddings = nn.ModuleList()
        # Physics Layers
        self.physics_layers = nn.ModuleList()
        self.physics_col_indices = []

        for i, col in enumerate(self.cat_feature_names):
            vocab = len(self.cat_maps[col])
            emb_dim = min(32, max(4, int(vocab**0.5 * 2)))
            self.embeddings.append(nn.Embedding(vocab, emb_dim))

            # Setup Physics Layer
            # CRITICAL: This block only runs if split_indices has data!
            if (
                self.p_class_idx != -1
                and col in EXCIPIENT_TYPE_MAPPING
                and col in CONC_TYPE_PAIRS.values()
            ):
                conc_col_name = [k for k, v in CONC_TYPE_PAIRS.items() if v == col][0]

                if conc_col_name in self.split_indices:
                    n_classes = len(self.cat_maps["Protein_class_type"])
                    n_regimes = len(self.cat_maps["Regime"])
                    n_excipients = len(self.cat_maps[col])

                    phys_layer = LearnablePhysicsPrior(
                        n_classes, n_regimes, n_excipients
                    )

                    # Initialize with robust logic
                    self._init_static_priors(phys_layer, col)

                    self.physics_layers.append(phys_layer)
                    self.physics_col_indices.append(i)
                else:
                    self.physics_layers.append(None)
                    self.physics_col_indices.append(-1)
            else:
                self.physics_layers.append(None)
                self.physics_col_indices.append(-1)

        total_emb = sum(e.embedding_dim for e in self.embeddings)

        self.regime_gate = None
        if self.regime_idx != -1:
            num_regimes = len(self.cat_maps["Regime"])
            self.regime_gate = nn.Embedding(num_regimes, 1)
            nn.init.constant_(self.regime_gate.weight, 1.0)

        # Residual Blocks
        self.residual_blocks = nn.ModuleList()
        for h in hidden_sizes:
            self.residual_blocks.append(ResidualBlock(h, dropout))

        # Base Network
        layers = []
        prev = total_emb + numeric_dim
        for h in hidden_sizes:
            layers.append(nn.Linear(prev, h))
            layers.append(nn.LayerNorm(h))
            layers.append(nn.ReLU())
            layers.append(nn.Dropout(dropout))
            prev = h
        self.base = nn.Sequential(*layers)

        # Heads
        self.heads = nn.ModuleList([nn.Linear(prev, 1) for _ in range(out_dim)])

    def _init_static_priors(self, layer, col_name):
        """
        Initializes the static prior tensor based on the EXCIPIENT_PRIORS table.
        Logic updated to map specific vocabulary items (e.g., 'tween-20', 'lysine')
        to their generic roles defined in the table.
        """
        p_classes = self.cat_maps["Protein_class_type"]
        regimes = self.cat_maps["Regime"]
        excipients = self.cat_maps[col_name]

        tensor = layer.static_scores

        with torch.no_grad():
            for p_i, p_val in enumerate(p_classes):
                for r_i, r_val in enumerate(regimes):
                    for e_i, e_val in enumerate(excipients):

                        # 1. Normalize Keys
                        p_key = p_val.lower().strip()
                        r_key = r_val.lower().strip()
                        e_key = e_val.lower().strip()

                        # 2. FIND PRIOR DICTIONARY (Tuple Lookup)
                        prior_dict = None

                        # Helper to find tuple key (class, regime) case-insensitively
                        def find_prior_dict(pk, rk):
                            if (pk, rk) in EXCIPIENT_PRIORS:
                                return EXCIPIENT_PRIORS[(pk, rk)]
                            # Slow scan fallback if strict match fails
                            for (dict_p, dict_r), val in EXCIPIENT_PRIORS.items():
                                if (
                                    str(dict_p).lower().strip() == pk
                                    and str(dict_r).lower().strip() == rk
                                ):
                                    return val
                            return None

                        # Primary Lookup
                        prior_dict = find_prior_dict(p_key, r_key)

                        # Fallback 1: noprotein
                        if prior_dict is None and (
                            p_key in ["noprotein", "none"] or r_key == "noprotein"
                        ):
                            prior_dict = find_prior_dict("noprotein", "noprotein")

                        # Fallback 2: other
                        if prior_dict is None:
                            prior_dict = find_prior_dict("other", r_key)

                        if prior_dict is None:
                            continue

                        # 3. LOOKUP EXCIPIENT VALUE
                        # Maps specific vocabulary words to generic prior keys
                        effect = 0.0
                        target_key = None

                        if "nacl" in e_key:
                            target_key = "nacl"
                        elif "arginine" in e_key:
                            target_key = "arginine"
                        elif "lysine" in e_key:
                            target_key = "lysine"
                        elif "proline" in e_key:
                            target_key = "proline"
                        elif "sucrose" in e_key or "trehalose" in e_key:
                            target_key = "stabilizer"  # Merged key
                        elif "tween" in e_key or "polysorbate" in e_key:
                            target_key = "tween"

                        if target_key:
                            # Direct check
                            if target_key in prior_dict:
                                effect = float(prior_dict[target_key])
                            else:
                                # Case-insensitive scan just in case
                                for k, v in prior_dict.items():
                                    if str(k).lower().strip() == target_key:
                                        effect = float(v)
                                        break

                        tensor[p_i, r_i, e_i] = effect

    def forward(
        self, x_num, x_cat, return_features=False, return_physics_details=False
    ):
        # 1. Embeddings & Base Network
        embs = [emb(x_cat[:, i]) for i, emb in enumerate(self.embeddings)]
        emb_cat = torch.cat(embs, dim=1)
        emb_cat = self.emb_drop(emb_cat)
        x = torch.cat([emb_cat, x_num], dim=1)
        x = self.base(x)

        if self.residual_blocks:
            for block in self.residual_blocks:
                x = block(x)

        if return_features:
            features = x.clone()

        outputs = [head(x) for head in self.heads]
        pred = torch.cat(outputs, dim=1)

        # 2. Learnable Physics Correction
        physics_details = {}

        if self.p_class_idx != -1:
            p_idx = x_cat[:, self.p_class_idx]
            r_idx = x_cat[:, self.regime_idx]
            total_correction = 0.0

            for i, phys_layer in enumerate(self.physics_layers):
                if phys_layer is not None:
                    e_idx = x_cat[:, i]
                    col_name = self.cat_feature_names[i]
                    conc_name = [
                        k for k, v in CONC_TYPE_PAIRS.items() if v == col_name
                    ][0]
                    # This relies on split_indices being correct
                    idx_low, idx_high = self.split_indices[conc_name]

                    val_low = x_num[:, idx_low : idx_low + 1]
                    val_high = x_num[:, idx_high : idx_high + 1]

                    # --- MASK LOGIC ---
                    none_idx = self.none_indices.get(col_name, -1)
                    if none_idx != -1:
                        mask = (e_idx != none_idx).float().unsqueeze(1)
                    else:
                        mask = torch.ones_like(e_idx).float().unsqueeze(1)

                    correction, layer_details = phys_layer(
                        p_idx, r_idx, e_idx, val_low, val_high
                    )

                    total_correction = total_correction + (correction * mask)

                    if return_physics_details:
                        # Pack the details for return
                        physics_details[col_name] = {
                            k: v * mask.squeeze() for k, v in layer_details.items()
                        }

            pred = pred + total_correction

        # 3. Regime Gate
        if self.regime_gate is not None and self.regime_idx != -1:
            gate = self.regime_gate(x_cat[:, self.regime_idx])
            gate = torch.sigmoid(gate)
            pred = pred * gate

        ret = [pred]
        if return_features:
            ret.append(features)
        if return_physics_details:
            ret.append(physics_details)

        if len(ret) == 1:
            return ret[0]
        return tuple(ret)

    def expand_categorical_embedding(
        self, feature_name: str, new_categories: List[str], initialization: str = "mean"
    ) -> None:
        """Expand an embedding layer to accommodate new categories."""
        if feature_name not in self.cat_feature_names:
            raise ValueError(f"Feature {feature_name} not in categorical features")

        idx = self.cat_feature_names.index(feature_name)
        old_emb = self.embeddings[idx]
        old_vocab_size = len(self.cat_maps[feature_name])
        new_vocab_size = old_vocab_size + len(new_categories)

        # 1. Create new embedding layer
        new_emb = nn.Embedding(new_vocab_size, old_emb.embedding_dim)

        # 2. Copy old weights and initialize new ones
        with torch.no_grad():
            # Copy existing knowledge
            new_emb.weight[:old_vocab_size] = old_emb.weight

            # Initialize new categories
            if initialization == "mean":
                mean_embedding = old_emb.weight.mean(dim=0)
                for i in range(len(new_categories)):
                    noise = torch.randn_like(mean_embedding) * 0.01
                    new_emb.weight[old_vocab_size + i] = mean_embedding + noise
            elif initialization == "zero":
                new_emb.weight[old_vocab_size:] = 0.0

        # 3. Replace the layer
        self.embeddings[idx] = new_emb

        # 4. Update internal map
        self.cat_maps[feature_name].extend(new_categories)

        # 5. Check Physics Layer Compatibility
        if self.physics_layers[idx] is not None:
            print(
                f"  [Warning] Expanded '{feature_name}' which has a Physics Prior attached."
            )
            print(
                f"            The new categories {new_categories} will have 0 physics effect"
            )
            print(f"            until the physics tensor is manually resized.")

        print(
            f"Expanded {feature_name} from {old_vocab_size} to {new_vocab_size} categories"
        )


class EnsembleModel(nn.Module):
    """Ensemble wrapper for multiple models with uncertainty quantification."""

    def __init__(self, models: List[nn.Module]):
        super().__init__()
        self.models = nn.ModuleList(models)

    @property
    def cat_maps(self) -> Dict:
        """Proxy to first model's cat_maps for consistent interface."""
        return self.models[0].cat_maps

    @property
    def cat_feature_names(self) -> List[str]:
        """Proxy to first model's cat_feature_names for consistent interface."""
        return self.models[0].cat_feature_names

    @property
    def embeddings(self) -> nn.ModuleList:
        """Proxy to first model's embeddings for consistent interface."""
        return self.models[0].embeddings

    def forward(self, x_num, x_cat):
        """Forward pass returning mean prediction."""
        outputs = [model(x_num, x_cat) for model in self.models]
        return torch.stack(outputs).mean(dim=0)

    def get_individual_predictions(self, x_num, x_cat):
        """Get predictions from each model individually for uncertainty estimation."""
        with torch.no_grad():
            outputs = [model(x_num, x_cat) for model in self.models]
        return torch.stack(outputs)  # (n_models, batch_size, n_targets)

    def expand_categorical_embedding(
        self, feature_name: str, new_categories: List[str], initialization: str = "mean"
    ) -> None:
        """Expand embeddings on all models in the ensemble."""
        for model in self.models:
            model.expand_categorical_embedding(
                feature_name, new_categories, initialization
            )


# --- PHYSICS-INFORMED LOSS ---


def get_physics_masks(
    X_cat: torch.Tensor, X_num: torch.Tensor, processor: "DataProcessor"
) -> Dict[str, torch.Tensor]:
    """
    Generate boolean masks for physics constraints based on batch data.

    CRITICAL UPDATE:
    Since X_num is scaled (Z-scores), we must unscale specific columns
    (like HCI) before applying absolute physical thresholds (e.g. HCI >= 1.3).

    Args:
        X_cat: Tensor of categorical indices (batch, n_cat)
        X_num: Tensor of numeric features (batch, n_num) [SCALED]
        processor: Fitted DataProcessor instance containing scaler stats

    Returns:
        Dictionary of masks for physics constraints
    """
    masks = {}
    device = X_cat.device

    try:
        # 1. Regime mask (Near or Mixed)
        if "Regime" in processor.categorical_features:
            idx_regime = processor.categorical_features.index("Regime")
            regime_map = processor.cat_maps["Regime"]

            # Find indices for 'near' and 'mixed' in the vocabulary
            near_idx = [i for i, x in enumerate(regime_map) if "near" in x.lower()]
            mixed_idx = [i for i, x in enumerate(regime_map) if "mixed" in x.lower()]

            target_regimes = torch.tensor(near_idx + mixed_idx, device=device)

            # Mask: Is Near or Mixed?
            masks["is_near_mixed"] = (
                torch.isin(X_cat[:, idx_regime], target_regimes).float().unsqueeze(1)
            )
        else:
            masks["is_near_mixed"] = torch.zeros(X_cat.shape[0], 1, device=device)

        # 2. Mask: High HCI? (HCI >= 1.3)
        if "HCI" in processor.numeric_features:
            hci_idx = processor.numeric_features.index("HCI")
            hci_vals = X_num[:, hci_idx]

            if (
                "HCI" in processor.scalable_features
                and hasattr(processor.scaler, "mean_")
                and processor.scaler.mean_ is not None
            ):

                scaler_idx = processor.scalable_features.index("HCI")
                mean_val = processor.scaler.mean_[scaler_idx]
                scale_val = processor.scaler.scale_[scaler_idx]

                # Convert to tensors on the correct device
                mean_t = torch.tensor(mean_val, device=device, dtype=torch.float32)
                scale_t = torch.tensor(scale_val, device=device, dtype=torch.float32)

                # Unscale: raw = z_score * std + mean
                hci_vals = hci_vals * scale_t + mean_t

            # Apply threshold on (now potentially raw) values
            masks["is_high_hci"] = (hci_vals >= 1.3).float().unsqueeze(1)
        else:
            masks["is_high_hci"] = torch.zeros(X_cat.shape[0], 1, device=device)

        # 3. Placeholder Masks for Excipients
        # (Could be expanded to check actual presence of excipients)
        masks["has_ionic"] = torch.ones(X_cat.shape[0], 1, device=device)
        masks["has_sucrose"] = torch.ones(X_cat.shape[0], 1, device=device)
        masks["has_tween"] = torch.ones(X_cat.shape[0], 1, device=device)

    except Exception as e:
        print(f"Warning: Could not build physics masks: {e}")
        # Fallback to zeros
        return {
            k: torch.zeros(X_cat.shape[0], 1, device=device)
            for k in [
                "is_near_mixed",
                "is_high_hci",
                "has_ionic",
                "has_sucrose",
                "has_tween",
            ]
        }

    return masks


def validate_data(
    X_num: np.ndarray, X_cat: np.ndarray, y: np.ndarray, name: str = "data"
) -> bool:
    """
    Validate data for NaN and Inf values.

    Args:
        X_num: Numeric features
        X_cat: Categorical features
        y: Target values
        name: Name for error messages

    Returns:
        True if validation passes

    Raises:
        ValueError: If data contains NaN or Inf values
    """
    if np.any(np.isnan(X_num)):
        raise ValueError(f"NaN in {name} numeric features")
    if np.any(np.isinf(X_num)):
        raise ValueError(f"Inf in {name} numeric features")
    if np.any(np.isnan(y)):
        raise ValueError(f"NaN in {name} targets")
    return True


def calculate_sample_weights(y_raw: np.ndarray) -> np.ndarray:
    """
    Calculate sample weights based on viscosity values.
    Emphasizes high viscosity samples which are rare but important.

    Args:
        y_raw: Raw target values (n_samples, n_targets)

    Returns:
        Sample weights (n_samples,)
    """
    # Viscosity_100 is usually the first target column
    v100 = y_raw[:, 0]

    # 1. Base weight: Logarithmic (Standard)
    # This prevents the massive range of values (1 to 1000+) from dominating gradients purely by magnitude
    weights = 1.0 + np.log1p(v100)

    # 2. Boost High Viscosity Samples
    # Samples > 20 cP are rare and exhibit exponential behavior.
    # We multiply their weight by 5.0 to force the model to fit the steep curve.
    high_vis_mask = v100 > 20.0
    weights[high_vis_mask] *= 5.0

    return weights.astype(np.float32)


class PhysicsInformedLoss(nn.Module):
    """
    Physics-informed loss function incorporating domain knowledge constraints.

    Combines:
    1. Standard MSE loss
    2. Shear-thinning constraint (viscosity should decrease with shear rate)
    3. Input gradient constraints from domain knowledge
    """

    def __init__(
        self,
        lambda_shear: float = 1.0,
        lambda_input: float = 0.1,
        numeric_cols: Optional[List[str]] = None,
    ):
        """
        Args:
            lambda_shear: Weight for shear-thinning constraint (output consistency).
            lambda_input: Weight for input-gradient constraints (Table D rules).
            numeric_cols: List of numeric column names to identify indices.
        """
        super().__init__()
        self.lambda_shear = lambda_shear
        self.lambda_input = lambda_input
        self.numeric_cols = numeric_cols or []

        # Pre-calculate indices for numeric features if possible
        self.idx_map = {name: i for i, name in enumerate(self.numeric_cols)}

    def forward(
        self,
        pred: torch.Tensor,
        target: torch.Tensor,
        inputs_num: torch.Tensor,
        masks: Dict[str, torch.Tensor],
        weights: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        Args:
            pred: Model outputs (batch, n_targets)
            target: True targets
            inputs_num: Numeric inputs (batch, n_features). MUST have requires_grad=True.
            masks: Dictionary containing boolean masks for the batch:
                   - 'is_near_mixed': (batch, 1) 1 if Regime is Near/Mixed
                   - 'is_high_hci': (batch, 1) 1 if HCI >= 1.3
                   - 'has_ionic': (batch, 1) 1 if Salt/Arg/Lys present
                   - 'has_sucrose': (batch, 1) 1 if Sucrose present
                   - 'has_tween': (batch, 1) 1 if Tween present
            weights: Sample weights
        """
        # 1. Standard MSE Loss
        squared_diff = (pred - target) ** 2
        if weights is not None:
            if weights.dim() == 1:
                weights = weights.unsqueeze(1)
            mse_loss = (squared_diff * weights).mean()
        else:
            mse_loss = squared_diff.mean()

        # 2. Shear Thinning Constraint (Output Monotonicity)
        # Viscosity should decrease (or stay same) as shear rate increases (next column)
        shear_loss = 0.0
        for i in range(pred.shape[1] - 1):
            # diff > 0 means Viscosity(High Shear) > Viscosity(Low Shear) -> Violation
            diff = pred[:, i + 1] - pred[:, i]
            violation = torch.relu(diff)
            shear_loss += violation.mean()

        # 3. Input Gradient Constraints (Table D from PDF)
        input_loss = 0.0

        # We need gradients of predictions w.r.t inputs to check sensitivity
        if self.lambda_input > 0 and inputs_num.requires_grad:
            # Calculate Gradients
            grads = torch.autograd.grad(
                outputs=pred.sum(),
                inputs=inputs_num,
                create_graph=True,
                retain_graph=True,
                only_inputs=True,
                allow_unused=True,
            )[0]

            # If inputs weren't used in the graph, grads will be None.
            if grads is not None:
                # Constraint A: Ionic Strength
                if "Salt_conc" in self.idx_map and "Excipient_conc" in self.idx_map:
                    idx_s = self.idx_map["Salt_conc"]
                    idx_e = self.idx_map["Excipient_conc"]
                    grad_ionic = grads[:, idx_s] + grads[:, idx_e]
                    mask_a = masks.get("is_near_mixed", 0) * masks.get("has_ionic", 0)
                    input_loss += (torch.relu(grad_ionic) * mask_a).mean()

                # Constraint B: Sucrose
                if "Stabilizer_conc" in self.idx_map:
                    idx_suc = self.idx_map["Stabilizer_conc"]
                    grad_suc = grads[:, idx_suc]
                    mask_b = masks.get("has_sucrose", 0)
                    input_loss += (torch.relu(-grad_suc) * mask_b).mean()

                # Constraint C: Tween
                if "Surfactant_conc" in self.idx_map:
                    idx_tw = self.idx_map["Surfactant_conc"]
                    grad_tw = grads[:, idx_tw]
                    mask_c = masks.get("is_high_hci", 0) * masks.get("has_tween", 0)
                    input_loss += (torch.relu(grad_tw) * mask_c).mean()

        total_loss = (
            mse_loss
            + (self.lambda_shear * shear_loss)
            + (self.lambda_input * input_loss)
        )
        return total_loss


# --- DATA PROCESSOR ---


class DataProcessor:
    """
    Handles all data preprocessing including:
    - Categorical encoding with vocabulary mapping
    - Numeric feature scaling
    - Feature engineering (Regime computation including 'noprotein')
    - Concentration Splitting (E_low / E_high)
    - Distance-based trust scores
    """

    def __init__(self, allow_new_categories: bool = False):
        self.cat_maps = {}
        self.scaler = StandardScaler()
        self.is_fitted = False
        self.categorical_features = BASE_CATEGORICAL.copy()
        self.numeric_features = BASE_NUMERIC.copy()
        self.allow_new_categories = allow_new_categories
        self.constant_features = []
        self.constant_values = {}
        self.scalable_features = []

        # [NEW] Track generated features and split indices
        # Maps original col name (e.g. 'Salt_conc') -> tuple of indices (idx_low, idx_high) in X_num
        self.split_indices = {}
        self.generated_feature_names = []

    def _compute_regime(self, df: pd.DataFrame) -> pd.Series:
        """
        Compute interaction regime based on CCI and Protein Class.
        [UPDATED]: Explicitly saves 'CCI_Score' to the dataframe for inspection.
        """
        regime = []

        # Pre-fetch columns
        has_p_conc = "Protein_conc" in df.columns
        has_p_type = "Protein_type" in df.columns

        # Ensure required columns exist
        req_cols = ["C_Class", "Buffer_pH", "PI_mean", "Protein_class_type"]
        missing = [c for c in req_cols if c not in df.columns]

        if "Protein_class" in df.columns and "Protein_class_type" in missing:
            df["Protein_class_type"] = df["Protein_class"]
            missing.remove("Protein_class_type")

        # --- UPDATE: Save CCI Score to DataFrame ---
        if not missing:
            tau = 1.5
            delta_ph = (df["Buffer_pH"] - df["PI_mean"]).abs()
            # Assign directly to df
            df["CCI_Score"] = df["C_Class"] * np.exp(-delta_ph / tau)
            cci_values = df["CCI_Score"]
        else:
            df["CCI_Score"] = np.nan
            cci_values = pd.Series([np.nan] * len(df), index=df.index)
        # -------------------------------------------

        for i in range(len(df)):
            row = df.iloc[i]

            # 1. DETECT NO PROTEIN
            is_no_protein = False
            if has_p_type:
                p_type = str(row.get("Protein_type", "")).lower()
                if p_type in ["none", "buffer", "nan", "null"]:
                    is_no_protein = True
            if has_p_conc:
                if row.get("Protein_conc", 0.0) <= 0.0:
                    is_no_protein = True

            if is_no_protein:
                regime.append("noprotein")
                continue

            # 2. CALCULATE REGIME
            if missing:
                regime.append("unknown")
                continue

            cci = cci_values.iloc[i]
            p_class = str(df["Protein_class_type"].iloc[i]).lower()

            if pd.isna(cci):
                regime.append("unknown")
                continue

            r = "unknown"
            # Logic from Table B
            if "igg1" in p_class:
                if cci >= 0.90:
                    r = "near"
                elif cci >= 0.50:
                    r = "mixed"
                else:
                    r = "far"
            elif "igg4" in p_class:
                if cci >= 0.80:
                    r = "near"
                elif cci >= 0.40:
                    r = "mixed"
                else:
                    r = "far"
            elif "fc-fusion" in p_class or "linker" in p_class:
                if cci >= 0.70:
                    r = "near"
                elif cci >= 0.40:
                    r = "mixed"
                else:
                    r = "far"
            elif "bispecific" in p_class or "adc" in p_class:
                if cci >= 0.80:
                    r = "near"
                elif cci >= 0.45:
                    r = "mixed"
                else:
                    r = "far"
            elif "bsa" in p_class or "polyclonal" in p_class:
                if cci >= 0.70:
                    r = "near"
                elif cci >= 0.40:
                    r = "mixed"
                else:
                    r = "far"
            else:
                if cci >= 0.90:
                    r = "near"
                elif cci >= 0.50:
                    r = "mixed"
                else:
                    r = "far"

            regime.append(r)

        return pd.Series(regime, index=df.index)

    def _construct_numeric_matrix(
        self, df: pd.DataFrame, is_fitting: bool = False
    ) -> Tuple[np.ndarray, List[str]]:
        """
        [NEW] Internal helper to build the numeric feature matrix.
        Handles the splitting of specific concentration columns into Low/High features.
        """
        feature_arrays = []
        gen_names = []
        new_split_indices = {}
        current_idx = 0

        for col in self.numeric_features:
            # Check if this column requires splitting (defined in CONC_TYPE_PAIRS)
            if col in CONC_TYPE_PAIRS:
                type_col = CONC_TYPE_PAIRS[col]

                # Get numeric values (fill NaNs with 0)
                if col in df.columns:
                    conc_vals = df[col].fillna(0.0).values
                else:
                    conc_vals = np.zeros(len(df))

                # Get type strings for threshold lookup
                if type_col in df.columns:
                    type_vals = (
                        df[type_col].fillna("none").astype(str).str.lower().values
                    )
                else:
                    type_vals = np.full(len(df), "none")

                # --- THRESHOLD LOGIC ---
                # Default threshold is arbitrarily high so E_low = conc, E_high = 0 if type unknown
                thresh_vals = np.full(len(df), 999999.0)

                # Vectorized-ish lookup
                for k, t_val in CONC_THRESHOLDS.items():
                    # Check if 'k' (e.g. 'sucrose') is in the type string (e.g. 'sucrose')
                    # List comprehension used for substring matching
                    mask = np.array([k in str(v) for v in type_vals])
                    thresh_vals[mask] = t_val

                # --- SPLIT CALCULATION ---
                # E_low = min(E, T)
                E_low = np.minimum(conc_vals, thresh_vals)
                # E_high = max(E - T, 0)
                E_high = np.maximum(conc_vals - thresh_vals, 0.0)

                feature_arrays.append(E_low)
                feature_arrays.append(E_high)

                gen_names.append(f"{col}_low")
                gen_names.append(f"{col}_high")

                # Record indices for the Model to use later
                new_split_indices[col] = (current_idx, current_idx + 1)
                current_idx += 2

            else:
                # --- STANDARD PROCESSING ---
                if col in self.constant_features:
                    vals = np.full(len(df), self.constant_values[col])
                elif col in df.columns:
                    vals = df[col].fillna(0.0).values
                else:
                    vals = np.zeros(len(df))

                feature_arrays.append(vals)
                gen_names.append(col)
                current_idx += 1

        # Stack all arrays horizontally
        X_combined = np.column_stack(feature_arrays)

        if is_fitting:
            self.generated_feature_names = gen_names
            self.split_indices = new_split_indices

        return X_combined, gen_names

    def fit_transform(self, df: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
        """Fit processor and transform data."""
        # 1. Fit Categorical (Regime vocabulary added here)
        self._fit_categorical(df)

        # 2. Fit Numeric (with Splitting)
        # Identify constant features first based on raw data
        for col in self.numeric_features:
            if col in df.columns:
                unique_vals = df[col].dropna().unique()
                if len(unique_vals) == 1:
                    self.constant_features.append(col)
                    self.constant_values[col] = unique_vals[0]

        # Construct the full matrix (handles splitting)
        X_num_full, _ = self._construct_numeric_matrix(df, is_fitting=True)

        # Fit Scaler on the EXPANDED matrix
        self.scaler.fit(X_num_full)

        self.is_fitted = True
        return self.transform(df)

    def transform(self, df: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
        """Transform data using fitted processor."""
        if not self.is_fitted:
            raise ValueError("Processor must be fitted first")

        X_cat = self._transform_categorical(df)

        # Construct numeric matrix (using fitted split logic)
        X_num_raw, _ = self._construct_numeric_matrix(df, is_fitting=False)

        # Apply scaling
        X_num = self.scaler.transform(X_num_raw)

        return X_num, X_cat

    def _fit_categorical(self, df: pd.DataFrame) -> None:
        """Build categorical vocabularies."""
        # Ensure Regime is in the list
        if "Regime" not in self.categorical_features:
            self.categorical_features.append("Regime")

        for col in self.categorical_features:
            if col == "Regime":
                # Preset Regime vocabulary including new 'noprotein'
                self.cat_maps["Regime"] = [
                    "far",
                    "mixed",
                    "near",
                    "noprotein",
                    "unknown",
                ]
                continue

            if col not in df.columns:
                print(f"Warning: {col} not in dataframe, skipping")
                self.cat_maps[col] = ["none"]
                continue

            unique_vals = df[col].dropna().unique().tolist()
            if "none" not in unique_vals:
                unique_vals.insert(0, "none")

            self.cat_maps[col] = unique_vals

    def _transform_categorical(self, df: pd.DataFrame) -> np.ndarray:
        """Transform categorical features to indices."""
        cat_data = []

        # Pre-compute regimes to handle 'noprotein' logic
        regime_series = self._compute_regime(df)

        for col in self.categorical_features:
            if col == "Regime":
                indices = [
                    (
                        self.cat_maps["Regime"].index(val)
                        if val in self.cat_maps["Regime"]
                        else self.cat_maps["Regime"].index("unknown")
                    )
                    for val in regime_series
                ]
            else:
                if col not in df.columns:
                    indices = [0] * len(df)
                else:
                    values = df[col].fillna("none").astype(str).str.lower()
                    indices = []
                    for val in values:
                        if val in self.cat_maps[col]:
                            indices.append(self.cat_maps[col].index(val))
                        else:
                            if self.allow_new_categories:
                                self.cat_maps[col].append(val)
                                indices.append(len(self.cat_maps[col]) - 1)
                            else:
                                indices.append(0)  # 'none'

            cat_data.append(indices)

        return np.array(cat_data, dtype=np.int64).T

    def compute_distance(self, X_num: np.ndarray) -> np.ndarray:
        """Compute trust distance."""
        if not hasattr(self.scaler, "mean_") or self.scaler.mean_ is None:
            return np.zeros(X_num.shape[0])
        distances = np.linalg.norm(X_num, axis=1)
        return distances

    def detect_new_categories(self, df: pd.DataFrame) -> Dict[str, List[str]]:
        """Detect categories that weren't seen during fitting."""
        new_cats = {}
        for col in self.categorical_features:
            if col == "Regime" or col not in df.columns:
                continue

            df_vals = set(df[col].dropna().astype(str).str.lower().unique())
            known_vals = set(self.cat_maps[col])
            unseen = df_vals - known_vals

            if unseen:
                new_cats[col] = list(unseen)
        return new_cats

    def add_categories(self, feature_name: str, new_categories: List[str]) -> None:
        """Add new categories to vocabulary."""
        if feature_name not in self.cat_maps:
            raise ValueError(f"Feature {feature_name} not found")

        for cat in new_categories:
            if cat not in self.cat_maps[feature_name]:
                self.cat_maps[feature_name].append(cat)
        print(f"Added {len(new_categories)} categories to {feature_name}")

    def get_vocab_sizes(self) -> Dict[str, int]:
        if not self.is_fitted:
            raise ValueError("Processor must be fitted first")
        return {col: len(self.cat_maps[col]) for col in self.categorical_features}

    def save(self, path: str) -> None:
        state = {
            "cat_maps": self.cat_maps,
            "scaler": self.scaler,
            "is_fitted": self.is_fitted,
            "categorical_features": self.categorical_features,
            "numeric_features": self.numeric_features,
            "allow_new_categories": self.allow_new_categories,
            "constant_features": self.constant_features,
            "constant_values": self.constant_values,
            "scalable_features": self.scalable_features,
            # [NEW] Persist split metadata
            "split_indices": self.split_indices,
            "generated_feature_names": self.generated_feature_names,
        }
        with open(path, "wb") as f:
            pickle.dump(state, f)

    def load(self, path: str) -> None:
        with open(path, "rb") as f:
            state = pickle.load(f)

        self.cat_maps = state["cat_maps"]
        self.scaler = state["scaler"]
        self.is_fitted = state["is_fitted"]
        self.categorical_features = state.get(
            "categorical_features", BASE_CATEGORICAL.copy()
        )
        self.numeric_features = state.get("numeric_features", BASE_NUMERIC.copy())
        self.allow_new_categories = state.get("allow_new_categories", False)
        self.constant_features = state.get("constant_features", [])
        self.constant_values = state.get("constant_values", {})
        self.scalable_features = state.get(
            "scalable_features", self.numeric_features.copy()
        )

        # [NEW] Load split metadata
        self.split_indices = state.get("split_indices", {})
        self.generated_feature_names = state.get("generated_feature_names", [])


# --- MODEL EVALUATION ---


def evaluate_model(
    model: nn.Module,
    processor: DataProcessor,
    data_path: str,
    output_prefix: str = "evaluation",
) -> Dict:
    """
    Comprehensive model evaluation with metrics and predictions.

    Args:
        model: Trained model (can be single or ensemble)
        processor: Fitted data processor
        data_path: Path to evaluation data CSV
        output_prefix: Prefix for output files

    Returns:
        Dictionary containing evaluation metrics
    """
    print("\n" + "=" * 70)
    print("Model Evaluation on Full Dataset")
    print("=" * 70)

    df = pd.read_csv(data_path)
    df_clean = clean(
        df,
        numeric_cols=BASE_NUMERIC,
        categorical_cols=BASE_CATEGORICAL,
        target_cols=TARGETS,
    )

    print(f"\nEvaluating on {len(df_clean)} samples")
    X_num, X_cat = processor.transform(df_clean)

    # Calculate Trust Distance
    trust_distances = processor.compute_distance(X_num)

    y_true = df_clean[TARGETS].values
    y_log = log_transform_targets(y_true)

    X_num_t, X_cat_t, y_log_t = to_tensors(X_num, X_cat, y_log)

    model.eval()
    with torch.no_grad():
        y_log_pred = model(X_num_t, X_cat_t).numpy()
    y_pred = inverse_log_transform(y_log_pred)

    # Compute metrics
    metrics = {}
    print("\nPer-Target Metrics:")
    print("-" * 70)

    for i, target_name in enumerate(TARGETS):
        y_true_target = y_true[:, i]
        y_pred_target = y_pred[:, i]

        mse = mean_squared_error(y_true_target, y_pred_target)
        rmse = np.sqrt(mse)
        mae = mean_absolute_error(y_true_target, y_pred_target)
        r2 = r2_score(y_true_target, y_pred_target)

        mask = y_true_target != 0
        if mask.sum() > 0:
            mape = (
                np.mean(
                    np.abs(
                        (y_true_target[mask] - y_pred_target[mask])
                        / y_true_target[mask]
                    )
                )
                * 100
            )
        else:
            mape = np.nan

        metrics[target_name] = {
            "MSE": mse,
            "RMSE": rmse,
            "MAE": mae,
            "R2": r2,
            "MAPE": mape,
        }

        print(f"\n{target_name}:")
        print(f"  MSE:  {mse:.4f}")
        print(f"  RMSE: {rmse:.4f}")
        print(f"  MAE:  {mae:.4f}")
        print(f"  R²:   {r2:.4f}")
        if not np.isnan(mape):
            print(f"  MAPE: {mape:.2f}%")

    print("\nOverall Metrics (averaged across targets):")
    print("-" * 70)
    overall_metrics = {
        "MSE": np.mean([m["MSE"] for m in metrics.values()]),
        "RMSE": np.mean([m["RMSE"] for m in metrics.values()]),
        "MAE": np.mean([m["MAE"] for m in metrics.values()]),
        "R2": np.mean([m["R2"] for m in metrics.values()]),
        "MAPE": np.nanmean([m["MAPE"] for m in metrics.values()]),
    }

    for metric_name, value in overall_metrics.items():
        if metric_name == "MAPE":
            print(f"  {metric_name}: {value:.2f}%")
        else:
            print(f"  {metric_name}: {value:.4f}")

    # Save detailed results
    results_df = df_clean.copy()
    results_df["Trust_Distance"] = trust_distances

    for i, target_name in enumerate(TARGETS):
        results_df[f"{target_name}_actual"] = y_true[:, i]
        results_df[f"{target_name}_predicted"] = y_pred[:, i]
        results_df[f"{target_name}_error"] = y_true[:, i] - y_pred[:, i]

        mask = y_true[:, i] != 0
        pct_error = np.zeros(len(y_true))
        pct_error[mask] = (
            (y_true[:, i][mask] - y_pred[:, i][mask]) / y_true[:, i][mask] * 100
        )
        results_df[f"{target_name}_pct_error"] = pct_error

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    results_file = f"{output_prefix}_predictions_{timestamp}.csv"
    results_df.to_csv(results_file, index=False)
    print(f"\nSaved predictions to: {results_file}")

    metrics_file = f"{output_prefix}_metrics_{timestamp}.json"
    all_metrics = {
        "per_target": metrics,
        "overall": overall_metrics,
        "n_samples": len(df_clean),
    }
    with open(metrics_file, "w") as f:
        json.dump(all_metrics, f, indent=2)
    print(f"Saved metrics to: {metrics_file}")

    return all_metrics


# --- MODEL MANAGEMENT ---


def expand_processor_and_model(
    processor: DataProcessor,
    model: Model,
    feature_name: str,
    new_categories: List[str],
    initialization: str = "mean",
) -> None:
    """Expand both processor and model for new categories."""
    processor.add_categories(feature_name, new_categories)
    model.expand_categorical_embedding(feature_name, new_categories, initialization)


class ResidualAdapter(nn.Module):
    """
    Residual Adapter network for domain adaptation.
    Added to core.py to ensure availability across modules.
    """

    def __init__(self, numeric_dim, cat_dims, embed_dim=16):
        super().__init__()
        self.num_proj = nn.Linear(numeric_dim, embed_dim)
        self.embeddings = nn.ModuleList([nn.Embedding(n, embed_dim) for n in cat_dims])
        # Output dim is len(TARGETS) imported from config section above
        self.net = nn.Sequential(
            nn.Linear(embed_dim * (len(cat_dims) + 1), 64),
            nn.ReLU(),
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Linear(32, len(TARGETS)),
        )

    def forward(self, x_num, x_cat):
        embs = [emb(x_cat[:, i]) for i, emb in enumerate(self.embeddings)]
        num_emb = self.num_proj(x_num)
        x = torch.cat(embs + [num_emb], dim=1)
        return self.net(x)


def attach_adapter(
    model: Model,
    adapter_state_dict: Dict,
    gating_thresholds: Optional[Dict[str, int]] = None,
) -> nn.Module:
    """
    Reconstructs an adapter and attaches it with dynamic gating.

    Args:
        model: The base model
        adapter_state_dict: Weights for the adapter
        gating_thresholds: Dict mapping feature names to their "base" vocab size.
                           Indices >= this size trigger the adapter.
    """
    # 1. Inspect model dimensions (same as before)
    cat_dims = [len(m) for m in model.cat_maps.values()]
    total_in = model.base[0].in_features
    total_emb = sum(e.embedding_dim for e in model.embeddings)
    numeric_dim = total_in - total_emb

    # 2. Initialize Adapter
    adapter = ResidualAdapter(numeric_dim, cat_dims, embed_dim=16)
    adapter.load_state_dict(adapter_state_dict)
    adapter.eval()

    # 3. Prepare Gating Logic
    original_forward = model.forward

    # If no thresholds provided, fallback to "always on" or legacy "last protein" logic
    # But strictly speaking, for this request, we want the threshold logic.
    checks = []
    if gating_thresholds:
        for feat, threshold in gating_thresholds.items():
            if feat in model.cat_feature_names:
                idx = model.cat_feature_names.index(feat)
                checks.append((idx, threshold))
    else:
        # Fallback: Try to guess or warn.
        # For safety, if no thresholds provided, we might assume the adapter
        # should active for the *very last* item in every list (legacy behavior approximation)
        print(
            "  [Core] Warning: No gating_thresholds provided. Adapter will default to Protein_type gating."
        )
        try:
            p_idx = model.cat_feature_names.index("Protein_type")
            p_thresh = len(model.cat_maps["Protein_type"]) - 1  # Only last one
            checks.append((p_idx, p_thresh))
        except ValueError:
            pass

    def new_forward(x_n, x_c, return_features=False):
        if return_features:
            base, feats = original_forward(x_n, x_c, return_features=True)
        else:
            base = original_forward(x_n, x_c)

        adapt = adapter(x_n, x_c)

        # Dynamic Masking
        mask = torch.zeros(x_c.size(0), 1, dtype=torch.bool, device=x_c.device)
        for col_idx, cutoff in checks:
            is_new = x_c[:, col_idx] >= cutoff
            mask = mask | is_new.unsqueeze(1)

        res = base + (adapt * mask.float())

        if return_features:
            return res, feats
        return res

    model.forward = new_forward
    print("  [Core] Adapter attached with thresholds.")
    return adapter


# --- MODEL MANAGEMENT ---


def save_model_checkpoint(
    model: nn.Module,
    processor: DataProcessor,
    best_params: Dict,
    filepath: str,
    adapter: Optional[nn.Module] = None,
) -> None:
    """
    Save model checkpoint with processor state (including split indices),
    hyperparameters, and optional adapter.
    """
    checkpoint = {
        "model_state_dict": model.state_dict(),
        "best_params": best_params,
        # Processor State
        "cat_maps": processor.cat_maps,
        "numeric_features": processor.numeric_features,
        "categorical_features": processor.categorical_features,
        "constant_values": processor.constant_values,
        "scalable_features": processor.scalable_features,
        # [NEW] Persist Split Metadata
        "split_indices": processor.split_indices,
        "generated_feature_names": processor.generated_feature_names,
        "scaler_state": {
            "mean_": processor.scaler.mean_,
            "scale_": processor.scaler.scale_,
            "n_features_in_": getattr(processor.scaler, "n_features_in_", 0),
        },
    }

    # --- SAVE ADAPTER STATE ---
    if adapter is not None:
        checkpoint["adapter_state_dict"] = adapter.state_dict()
        checkpoint["has_adapter"] = True
    else:
        # Check if the model itself has a detached state dict stored
        if (
            hasattr(model, "adapter_state_dict")
            and model.adapter_state_dict is not None
        ):
            checkpoint["adapter_state_dict"] = model.adapter_state_dict
            checkpoint["has_adapter"] = True
        else:
            checkpoint["has_adapter"] = False

    torch.save(checkpoint, filepath)
    print(
        f"Saved checkpoint to: {filepath} (Adapter saved: {checkpoint['has_adapter']})"
    )


def load_model_checkpoint(
    filepath: str, device: str = "cpu"
) -> Tuple[Model, DataProcessor, Dict]:
    """
    Load model checkpoint.
    Correctly initializes Model with split_indices and expanded numeric dimensions.
    """
    checkpoint = torch.load(filepath, map_location=device, weights_only=False)

    # Reconstruct processor
    processor = DataProcessor()
    processor.cat_maps = checkpoint.get("cat_maps", {})
    processor.numeric_features = checkpoint.get("numeric_features", [])
    processor.categorical_features = checkpoint.get("categorical_features", [])
    processor.constant_values = checkpoint.get("constant_values", {})
    processor.scalable_features = checkpoint.get(
        "scalable_features", processor.numeric_features.copy()
    )
    processor.constant_features = list(processor.constant_values.keys())

    # [NEW] Restore Split Metadata
    processor.split_indices = checkpoint.get("split_indices", {})
    processor.generated_feature_names = checkpoint.get("generated_feature_names", [])

    processor.allow_new_categories = False
    processor.is_fitted = True

    # Rebuild scaler
    scaler_state = checkpoint.get("scaler_state", None)
    if scaler_state is not None:
        processor.scaler = StandardScaler()
        processor.scaler.mean_ = np.asarray(scaler_state["mean_"], dtype=np.float64)
        processor.scaler.scale_ = np.asarray(scaler_state["scale_"], dtype=np.float64)
        processor.scaler.n_features_in_ = int(scaler_state["n_features_in_"])
        if "feature_names_in_" in scaler_state:
            processor.scaler.feature_names_in_ = np.array(
                scaler_state["feature_names_in_"]
            )

        # [CRITICAL] Determine numeric_dim from the SCALER, not the raw feature list.
        # This accounts for the extra columns created by splitting (E_low, E_high).
        actual_numeric_dim = len(processor.scaler.mean_)
    else:
        processor.scaler = None
        actual_numeric_dim = len(processor.numeric_features)  # Fallback

    # Reconstruct model
    best_params = checkpoint["best_params"]
    hidden_size = best_params["hidden_size"]
    n_layers = best_params["n_layers"]
    hidden_sizes = [hidden_size] * n_layers

    model = Model(
        cat_maps=processor.cat_maps,
        numeric_dim=actual_numeric_dim,  # [UPDATED] Uses actual input dimension
        out_dim=len(TARGETS),
        hidden_sizes=hidden_sizes,
        dropout=best_params["dropout"],
        split_indices=processor.split_indices,  # [UPDATED] Pass split map to Model
    )

    # Handle Ensemble Keys
    state_dict = checkpoint["model_state_dict"]
    first_key = next(iter(state_dict.keys()))
    if first_key.startswith("models."):
        print(
            "  [INFO] Detected Ensemble checkpoint. Extracting weights for single Model..."
        )
        new_state_dict = {}
        for k, v in state_dict.items():
            if k.startswith("models.0."):
                new_key = k.replace("models.0.", "")
                new_state_dict[new_key] = v
        state_dict = new_state_dict

    model.load_state_dict(state_dict)
    model.to(device)

    # Attach adapter state dict to model for downstream use
    if "adapter_state_dict" in checkpoint:
        model.adapter_state_dict = checkpoint["adapter_state_dict"]
        print(f"  [INFO] Adapter state found and attached to model.adapter_state_dict")
    else:
        model.adapter_state_dict = None

    print(f"Loaded checkpoint from: {filepath}")

    return model, processor, best_params
